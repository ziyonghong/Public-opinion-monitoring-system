a = 0
with open("./test3.html","r",encoding="utf-8") as ff:
    lines = ff.readlines()
with open("./test3.html","w",encoding="utf-8") as ee:
    for line in lines:
        if "symbolSize:" in line and a<21:
            line = line.replace("100", "10")
            ee.write(line)
            a += 1
        else:
            ee.write(line)