def insert_people(number,insert_line):
    print("------开始插入人物列表------")
    line_number = 0     ##行数
    with open("./test3.html","r",encoding="utf-8") as e:
        lines = e.readlines()
    with open("./test3.html","w",encoding="utf-8") as ee:
        for line in lines:
            line_number += 1
            if(line_number == insert_line):
                number += 1
                if "]" in line:
                    line = line.replace("]",(number-1)*'''{
                            name: 'name000',       //姓名
                            //des: '1',        //点击在图标上显示的汉字
                            symbolSize: 100,
                            itemStyle: {
                                normal: {
                                    color: 'red'
                                }
                            }
                        },''')+'''{
                            name: 'name000',       //姓名
                            //des: '1',        //点击在图标上显示的汉字
                            symbolSize: 100,
                            itemStyle: {
                                normal: {
                                    color: 'red'
                                }
                            }
                        }
                        ],'''
                    ee.write(line)
                else:
                    ee.write(line)
            else:
                ee.write(line)
    ee.close()
    print("------结束插入人物列表------")

def insert_relate(number,insert_line):
    print("------开始插入关系列表------")
    line_number = 0     ##行数
    with open("./test3.html","r",encoding="utf-8") as f:
        lines = f.readlines()
    with open("./test3.html","w",encoding="utf-8") as ff:
        for line in lines:
            line_number += 1
            if(line_number == insert_line):
                if "]" in line:
                    line = line.replace("]",(number-1)*'''{
                            source: 'source111',     //横线的头
                            target: 'target111',     //横线指向的目标
                            name: 'name111',       //两人之间的关系
                            // des: ''  //横线上面显示的关系
                        },''')+'''{
                            source: 'source111',     //横线的头
                            target: 'target111',     //横线指向的目标
                            name: 'name111',       //两人之间的关系
                            // des: ''  //横线上面显示的关系
                        }
                        ],'''
                    ff.write(line)
                else:
                    ff.write(line)
            else:
                ff.write(line)
    ff.close()
    print("------结束插入关系列表------")


def replace(data):
    ###人物替换
    print("------开始替换html人物和关系对------")
    people = []
    with open("./nameNumber.txt","r",encoding="utf-8") as f:
        lines = f.readlines()
        for line in lines:
            people.append(line.strip())

    ###人物之间的关系替换
    txt_list = []
    with open("./Relate.txt","r",encoding="utf-8") as ff:
        txt_line = ff.readlines()
        for i in txt_line:
            txt_list.append((i.strip().split(" ")))
    su = 0
    i = 0
    k = 0
    with open("./test3.html","r",encoding="utf-8") as f:
        lines = f.readlines() 
    # 写的方式打开文件
    with open("./test3.html","w",encoding="utf-8") as f_w:
        for line in lines:
            if "name000" in line:
                line = line.replace("name000",people[i])
                i += 1
                f_w.write(line)
            elif "red" in line:
                if(0<int(data[k])<1):
                    line = line.replace("red","gray")
                    f_w.write(line)
                    k += 1
                elif(1<=int(data[k])<3):
                    line = line.replace("red","bule")
                    k += 1
                elif(3<=int(data[k])<5):
                    line = line.replace("red","purple")
                    f_w.write(line)
                    k += 1
                elif(5<=int(data[k])<10):
                    line = line.replace("red","yellow")
                    f_w.write(line)
                    k += 1
                elif(10<=int(data[k])<20):
                    line = line.replace("red","green")
                    f_w.write(line)  
                    k += 1
                else:
                    line = line.replace("red","red")
                    f_w.write(line)
                    k += 1
            elif "source111" in line:
            #替换
                line = line.replace("source111",txt_list[su][0])
                f_w.write(line)
                
            elif "target111" in line:
            #替换
                line = line.replace("target111",txt_list[su][1])
                f_w.write(line)
                
            elif "name111" in line:
            #替换
                line = line.replace("name111",txt_list[su][2])
                f_w.write(line)
                su += 1
            else:
                f_w.write(line)
    f_w.close()
    print("------结束替换html人物和关系对------")

def peopleAndRalate():
    ##切割人物并且返回人物的数量
    num_people = 0
    num_relate = 0
    data = []
    with open("./nameNumber.txt", "r", encoding="utf-8") as f:
        lines = f.readlines()
    with open("./nameNumber.txt", "w", encoding="utf-8") as ff:
        for line in lines:
            num_people += 1
            a = line.split(" ")
            ff.writelines(str(a[0])+"\n")
            data.append(a[2].strip())
        ff.close()
            # print(line.split(" "))
    ##返回人物关系对数
    with open("./Relate.txt","r",encoding="utf-8") as dd:
        lines = dd.readlines()
        for line in lines:
            num_relate += 1
    return (num_people,num_relate,data)

##获得link最后一个]的行数,定位功能
def local():
    line_num = 0
    with open("./test3.html","r",encoding="utf-8") as bb:
        lines = bb.readlines()
        for line in lines:
            line_num += 1
    line_num -= 7
    return line_num

print("------测试开始------")
##切割人物并且返回人物数和关系对数
data = peopleAndRalate()
print(data)

##向html里面插入人物数
insert_people(data[0]-2, 81)

line_relate = local()

# print(line_relate)
##向html里面插入关系对数
insert_relate(data[1]-1,line_relate)
##替换人物和关系对
# replace(data[2])

print("------测试结束------")