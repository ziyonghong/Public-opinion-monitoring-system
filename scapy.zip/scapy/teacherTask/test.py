import csv

def start():
    print("------测试开始------")
    csvFile = open("./chat_data.csv","r",encoding="utf-8")
    
    reader = csv.reader(csvFile)
    name = []   ##储存名字
    relate = []     ##存储任务的关系
    for item in reader:
        if reader.line_num%2 == 0:
            continue
        test = []
        name_1 = item[0].split("-")[0]
        name_2 = item[0].split("-")[1]
        name.append(name_1)
        name.append(name_2)
        test.append(name_1)
        test.append(name_2)
        test.append(item[1])
        relate.append(test)
        # print(item)
        # print(reader.line_num)

    # print(reader)
    ##------去掉相同的元素------
    list1 = list(set(name))

    ##------统计每个元素出现的个数------
    number = {}
    for i in list1:
        k = name.count(i)
        number[i] = k

    # print("------写入人物数量文件------")
    # with open("./nameNumber.txt","w",encoding="utf-8") as ff:
    #     for j in number:
    #         ff.writelines(j+" "+j+" "+str(number[j])+'\n')
    # ff.close()


    print("------写入人物关系文件------")
    with open("./Relate.txt","w",encoding="utf-8") as ee:
        for k in relate:
            ee.writelines(k[0]+" "+k[1]+" "+k[2]+'\n')
    ee.close()
    csvFile.close()
    print("------测试结束------")

start()