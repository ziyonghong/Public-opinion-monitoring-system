# 关键字之间的关系
import random

word = []
data = []
with open("./word_relation_data.csv", "r", encoding="gbk") as file:
    lines = file.readlines()
    for line in lines:
        if (len(line) == 1):
            continue
        temp = line.split(",")
        temp_1 = temp[0].split("-")
        word.append(temp_1[0])
        word.append(temp_1[1])

        a = []
        a.append(temp_1[0])
        a.append(temp_1[1])
        a.append(temp[1].replace("\n",""))
        data.append(a)




word = list(set(word))

def insert_people(number,insert_line):
    print("------开始插入圆圈------")
    line_number = 0     ##行数
    with open("./key_word.html","r",encoding="utf-8") as e:
        lines = e.readlines()
    with open("./key_word.html","w",encoding="utf-8") as ee:
        for line in lines:
            line_number += 1
            if(line_number == insert_line):
                number += 1
                if "]" in line:
                    line = line.replace("]",(number-1)*'''{
                            name: 'name000',       //姓名
                            //des: '1',        //点击在图标上显示的汉字
                            symbolSize: 100,
                            itemStyle: {
                                normal: {
                                    color: 'red'
                                }
                            }
                        },''')+'''{
                            name: 'name000',       //姓名
                            //des: '1',        //点击在图标上显示的汉字
                            symbolSize: 100,
                            itemStyle: {
                                normal: {
                                    color: 'red'
                                }
                            }
                        }
                        ],'''
                    ee.write(line)
                else:
                    ee.write(line)
            else:
                ee.write(line)
    ee.close()
    print("------结束插入圆圈个数------")

##获得link最后一个]的行数,定位功能
def local():
    line_num = 0
    with open("./key_word.html","r",encoding="utf-8") as bb:
        lines = bb.readlines()
        for line in lines:
            line_num += 1
    line_num -= 7
    return line_num

def changeWord(word):
    key_number = {}
    with open("./wordNumber.txt", "r", encoding="utf-8") as file_2:
        lines = file_2.readlines()
        for line in lines:
            temp = line.split(" ")
            key_number[temp[0]] = int(temp[2].replace("\n", ""))
    # print(key_number)
    i = 0
    with open("./key_word.html", "r", encoding="utf-8") as file_1:
        lines = file_1.readlines()
        # 写的方式打开文件
        with open("./key_word.html", "w", encoding="utf-8") as f_w:
            for line in lines:
                if "name000" in line:
                    line = line.replace("name000", word[i])
                    i += 1
                    f_w.write(line)
                elif "color" in line:
                    k =  random.randint(0, 5)
                    a = ["green", "blue", "yellow", "red", "purple", "black"]
                    line = line.replace("red", a[k])
                    f_w.write(line)
                elif "symbolSize" in line:
                    j = random.randint(0, 4)
                    c = ["90", "70", "60", "50", "30"]
                    line = line.replace("100", c[j])
                    f_w.write(line)
                else:
                    f_w.write(line)

        f_w.close()



def insert_relate(number,insert_line):
    print("------开始插入关系列表------")
    line_number = 0     ##行数
    with open("./key_word.html","r",encoding="utf-8") as f:
        lines = f.readlines()
    with open("./key_word.html","w",encoding="utf-8") as ff:
        for line in lines:
            line_number += 1
            if(line_number == insert_line):
                if "]" in line:
                    line = line.replace("]",(number-1)*'''{
                            source: 'source111',     //横线的头
                            target: 'target111',     //横线指向的目标
                            name: 'name111',       //两人之间的关系
                            // des: ''  //横线上面显示的关系
                        },''')+'''{
                            source: 'source111',     //横线的头
                            target: 'target111',     //横线指向的目标
                            name: 'name111',       //两人之间的关系
                            // des: ''  //横线上面显示的关系
                        }
                        ],'''
                    ff.write(line)
                else:
                    ff.write(line)
            else:
                ff.write(line)
    ff.close()
    print("------结束插入关系列表------")


def replace(data):
    i = 0
    with open("./key_word.html", "r", encoding="utf-8") as file_2:
        lines = file_2.readlines()
    with open("./key_word.html", "w", encoding="utf-8") as file_3:
        for line in lines:
            if "source111" in line:
                print(data[i])
                print(data[i][0])
                print(i)
                line = line.replace("source111", data[i][0])
                file_3.write(line)
                continue
            elif "target111" in line:
                line = line.replace("target111", data[i][1])
                file_3.write(line)
                continue
            elif "name111" in line:
                line = line.replace("name111", data[i][2])
                file_3.write(line)
                i += 1
                continue
            else:
                file_3.write(line)



number = len(word)
print(number)
insert_people(number - 2, 81)
line_relate = local()
changeWord(word)
insert_relate(len(data)-1, line_relate)
replace(data)

