import csv

number = []
file = open("./wordcount.csv","r",encoding="utf8")
reader = csv.reader(file)
for item in reader:
    if reader.line_num%2 == 0:
        continue
    test = []
    test.append(item[0])
    test.append(item[0])
    test.append(item[1])
    number.append(test)

with open("./nameNumber.txt","w",encoding="utf8") as ff:
    for i in number:
        if int(i[2])<=40:
            break
        ff.writelines(i[0]+" "+i[1]+" "+i[2]+'\n')    

file.close()

with open("./word_relation_data.csv", "r", encoding="gbk") as fff:
    lines = fff.readlines()
    for line in lines:
        if len(line) == 1:
            continue
        temp = line.split(",")
        te = temp[0].split("-")
        with open("./Relate.txt", "a+", encoding="utf-8") as relateFile:
            relateFile.write(te[0]+" "+te[1]+"\n")