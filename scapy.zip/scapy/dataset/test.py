import csv

csvfile = open('./tieba_data_new.csv', 'w')
writer = csv.writer(csvfile)
writer.writerow(['\n想上树的猪1011\n', '            有没有新生群', '2019-06-26'])
writer.writerow(['\n想上树的猪1011\n', '            有没有新生群', '2019-06-26'])