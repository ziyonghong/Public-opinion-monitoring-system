# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import re
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import networkx as nx
import matplotlib.pyplot as plt
from pylab import mpl
from PyQt5 import QtCore, QtGui, QtWidgets

mpl.rcParams['font.sans-serif'] = ['FangSong'] # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题

class Ui_Dialog1(object):
    # 公共属性
    node_sum = 0  # 一共有几个点
    node_list = []  # 这些点的标签
    edge_sum = 0  # 一共有几条边
    edge_list = []  # 这些边的权重
    edge1 = []  # 记录边的起始点
    edge2 = []  # 记录边的终止点
    def setupUi(self, Dialog):
        Dialog.setObjectName("样例文书分析")
        Dialog.resize(800, 600)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(33, 30, 201, 61))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("图标2.png"))
        self.label.setObjectName("label")
        self.comboBox = QtWidgets.QComboBox(Dialog)
        self.comboBox.setGeometry(QtCore.QRect(0, 0, 69, 22))
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("file")
        self.comboBox.addItem("One")
        self.comboBox.addItem("Two")
        self.comboBox.addItem("Three")
        self.comboBox.addItem("Four")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(310, 20, 211, 81))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("图标3.png"))
        self.label_2.setObjectName("label_2")
        self.textEdit = QtWidgets.QTextEdit(Dialog)
        self.textEdit.setGeometry(QtCore.QRect(30, 120, 201, 251))
        self.textEdit.setObjectName("textEdit")
        self.textEdit.resize(250,300)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(300, 100, 54, 12))
        self.label_3.setObjectName("label_3")
        self.label_3.resize(500,400)
        self.comboBox.currentIndexChanged.connect(self.selectionchange)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_3.setText(_translate("Dialog", " "))
    def selectionchange(self):
        name = self.comboBox.currentText()
        self.textEdit.clear()
        self.txtborn(name)
        self.label_3.setPixmap(QtGui.QPixmap('123.png'))
        self.label_3.setScaledContents(True)  # 让图片自适应label大小
        # 以下是操作函数
        # 公诉机关函数--从str中找出公诉机关名

    def gongsujiguan(self, str):
        pat = re.compile('公诉机关(.*?)。')
        result = pat.search(str).group(1)
        return result
        # 被告信息函数--从str中找出符合被告人信息条的所有内容

    def beigaoxinxi(self, str):
        pat = re.compile('被告人.*?，.*?族，.*?住.*?[,。]')
        result = pat.findall(str)
        return result

        # 信息分类函数--对str进行分类，返回分类后的列表

    def xinxifenlei(self, str, anjianming, beigao_count):
        zhurengong = re.search(r'被告人(.*?)，', str).group(1)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(zhurengong)
        self.textEdit.append(anjianming + "," + zhurengong + ",被告\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("被告")
        self.edge1.append(1)
        self.edge2.append(beigao_count)

        pat = re.compile('，.*?([男|女])，')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",性别\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("性别")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 1)

        pat = re.compile('([1|2].*?年.*?月.*?日)出生')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",出生日期\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("出生日期")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 2)

        pat = re.compile('，(.{1,3})族')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",民族\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("民族")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 3)

        pat = re.compile('，(..文化)')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",文化水平\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("文化水平")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 4)

        pat = re.compile('住(.*?)[，。]')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",住址\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("住址")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 5)

        # 罪行信息函数--从str中找出符合罪行信息条的所有内容

    def zuixingxinxi(self, str):
        pat = re.compile('[一二三四五六七八九十]、被告人.*?罪，判处.*?[，。；（]')
        result = pat.findall(str)
        return result

        # 罪行分类函数--对str进行分类，返回分类后的列表

    def zuixingfenlei(self, str):
        qiekai = []
        pat = re.compile('被告人(.*?)犯')
        xingming = pat.search(str).group(1)
        qiekai.append(xingming)
        pat = re.compile('犯(.*?)罪')
        zuixing = pat.search(str).group(1)
        qiekai.append(zuixing)
        pat = re.compile('判处(.*?)[，。；（]')
        panjue = pat.search(str).group(1)
        qiekai.append(panjue)
        return qiekai

    def txtborn(self, str):
        self.edge_sum = 0
        self.node_sum = 0
        self.edge_list = []
        self.node_list = []
        self.edge1 = []
        self.edge2 = []
        # self.textEdit.append.write("Source,Target,Label\n")

        str =  str + ".txt"

        # 读文件第三行，获得案件编号
        f = open(str)
        anjianming = f.readlines()[2]
        anjianming = re.sub('\n', '', anjianming)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(anjianming)  # 增加案件名到点标签列表
        f.close()

        # 读文件第四行，获得公诉机关
        f = open(str)
        jiguanming = f.readlines()[3]
        jiguanming = self.gongsujiguan(jiguanming)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(jiguanming)  # 增加机关名到点标签列表
        f.close()
        self.textEdit.append(anjianming + "," + jiguanming + ",公诉机关\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("公诉机关")
        self.edge1.append(1)
        self.edge2.append(2)
        # 读文件第一行，获得审理机关
        f = open(str)
        shenli = f.readlines()[0]
        shenli = re.sub('\n', '', shenli)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(shenli)  # 增加机关名到点标签列表
        f.close()
        self.textEdit.append(anjianming + "," + shenli + ",被审理\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("被审理")
        self.edge1.append(1)
        self.edge2.append(3)
        # 读文件，进行字符串提取信息
        f = open(str)
        txt = f.read()

        xinxihuizong = self.beigaoxinxi(txt)  # 信息汇总是收集所有被告人信息的列表
        beigao_count = 4
        beigao_sum = 0
        for i in xinxihuizong:
            self.xinxifenlei(i, anjianming, beigao_count)
            beigao_count = beigao_count + 6
            beigao_sum = beigao_sum + 1
        beigao_count = 4
        zuixinghuizong = self.zuixingxinxi(txt)  # 罪行汇总是收集所有罪行信息的列表
        xingfa_count = 0
        for i in zuixinghuizong:
            fenleihou = self.zuixingfenlei(i)
            self.textEdit.append(fenleihou[0] + "," + fenleihou[1] + ",罪行\n")
            self.node_sum = self.node_sum + 1
            self.node_list.append(fenleihou[1])
            self.edge_sum = self.edge_sum + 1
            self.edge_list.append("罪行")
            self.edge1.append(beigao_count)
            self.edge2.append(4 + beigao_sum * 6 + xingfa_count * 2)

            self.textEdit.append(fenleihou[0] + "," + fenleihou[2] + ",刑罚\n")
            self.node_sum = self.node_sum + 1
            self.node_list.append(fenleihou[2])
            self.edge_sum = self.edge_sum + 1
            self.edge_list.append("刑罚")
            self.edge1.append(beigao_count)
            self.edge2.append(5 + beigao_sum * 6 + xingfa_count * 2)
            beigao_count = beigao_count + 6
            xingfa_count = xingfa_count + 1
        self.huitu()

    def huitu(self):
        i = 1
        G = nx.DiGraph()  # 创建一个空的有向图
        # 点的创建
        while self.node_sum != 0:
            G.add_node(i)
            i = i + 1
            self.node_sum = self.node_sum - 1
        # 边的创建
        j = 0
        while self.edge_sum != 0:
            G.add_edge(self.edge1[j], self.edge2[j], weight=self.edge_list[j])
            self.edge_sum = self.edge_sum - 1
            j = j + 1
        # 生成节点标签
        labels = {}
        j = 1
        for i in self.node_list:
            labels[j] = i
            j = j + 1

        # 获取graph中的边权重
        edge_labels = nx.get_edge_attributes(G, 'weight')
        # 生成节点位置
        pos = nx.shell_layout(G)
        # 把节点画出来
        nx.draw_networkx_nodes(G, pos, node_size=100, node_color='r', alpha=0.3)

        # 把边画出来
        nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5, edge_color='r', )  # 边是红色的

        # 把节点的标签画出来
        nx.draw_networkx_labels(G, pos, labels, font_size=7, font_color='b')  # 节点标签是蓝色的

        # 把边权重画出来
        nx.draw_networkx_edge_labels(G, pos, edge_labels, font_size=7, font_color='g', )
        plt.savefig("123.png", bbox_inches='tight')
        plt.close()

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(600, 400)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(100, 100, 411, 111))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("图标.png"))
        self.label.setObjectName("label")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(224, 252, 141, 61))
        self.pushButton.setObjectName("pushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "开始使用"))
class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(110, 100, 161, 51))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(114, 190, 161, 51))
        self.pushButton_2.setObjectName("pushButton_2")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(133, 31, 111, 31))
        self.label.setObjectName("label")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.pushButton.setText(_translate("Dialog", "样例文书"))
        self.pushButton_2.setText(_translate("Dialog", "输入文书"))
        self.label.setText(_translate("Dialog", "    选择文书来源"))
class Ui_Dialog2(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(558, 492)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(73, 20, 401, 81))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("图标1.png"))
        self.label.setObjectName("label")
        self.textEdit = QtWidgets.QTextEdit(Dialog)
        self.textEdit.setGeometry(QtCore.QRect(70, 140, 401, 211))
        self.textEdit.setObjectName("textEdit")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(200, 119, 131, 21))
        self.label_2.setObjectName("label_2")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(204, 390, 131, 51))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.button_choose)
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
    def button_choose(self):
        txt=self.textEdit.toPlainText()
        f=open("S.txt","w")
        f.write(txt)
        f.close()
        self.child = QDialog()  # 实例化子窗口
        self.child_ui = Ui_Dialog3()  # 第一个子窗口的地址为ui1
        self.child_ui.setupUi(self.child)
        self.child.show()

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_2.setText(_translate("Dialog", "      文本输入处"))
        self.pushButton.setText(_translate("Dialog", "保存"))
class Ui_Dialog3(object):
    #公共属性
    node_sum = 0  # 一共有几个点
    node_list = []  # 这些点的标签
    edge_sum = 0  # 一共有几条边
    edge_list = []  # 这些边的权重
    edge1 = []  # 记录边的起始点
    edge2 = []  # 记录边的终止点
    def setupUi(self, Dialog):
        Dialog.setObjectName("样例文书分析")
        Dialog.resize(800, 600)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(33, 30, 201, 61))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("图标2.png"))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(310, 20, 211, 81))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("图标3.png"))
        self.label_2.setObjectName("label_2")
        self.textEdit = QtWidgets.QTextEdit(Dialog)
        self.textEdit.setGeometry(QtCore.QRect(30, 120, 201, 251))
        self.textEdit.setObjectName("textEdit")
        self.textEdit.resize(250,300)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(300, 100, 54, 12))
        self.label_3.setObjectName("label_3")
        self.label_3.resize(500,400)
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        self.selectionchange()
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_3.setText(_translate("Dialog", " "))
    def selectionchange(self):
        name = "S.txt"
        self.txtborn(name)
        self.label_3.setPixmap(QtGui.QPixmap('123.png'))
        self.label_3.setScaledContents(True)  # 让图片自适应label大小
        # 以下是操作函数
        # 公诉机关函数--从str中找出公诉机关名

    def gongsujiguan(self, str):
        pat = re.compile('公诉机关(.*?)。')
        result = pat.search(str).group(1)
        return result
        # 被告信息函数--从str中找出符合被告人信息条的所有内容

    def beigaoxinxi(self, str):
        pat = re.compile('被告人.*?，.*?族，.*?住.*?[,。]')
        result = pat.findall(str)
        return result

        # 信息分类函数--对str进行分类，返回分类后的列表

    def xinxifenlei(self, str, anjianming, beigao_count):
        zhurengong = re.search(r'被告人(.*?)，', str).group(1)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(zhurengong)
        self.textEdit.append(anjianming + "," + zhurengong + ",被告\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("被告")
        self.edge1.append(1)
        self.edge2.append(beigao_count)

        pat = re.compile('，.*?([男|女])，')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",性别\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("性别")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 1)

        pat = re.compile('([1|2].*?年.*?月.*?日)出生')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",出生日期\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("出生日期")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 2)

        pat = re.compile('，(.{1,3})族')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",民族\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("民族")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 3)

        pat = re.compile('，(..文化)')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",文化水平\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("文化水平")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 4)

        pat = re.compile('住(.*?)[，。]')
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(pat.search(str).group(1))
        self.textEdit.append(zhurengong + "," + pat.search(str).group(1) + ",住址\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("住址")
        self.edge1.append(beigao_count)
        self.edge2.append(beigao_count + 5)

        # 罪行信息函数--从str中找出符合罪行信息条的所有内容

    def zuixingxinxi(self, str):
        pat = re.compile('[一二三四五六七八九十]、被告人.*?罪，判处.*?[，。；（]')
        result = pat.findall(str)
        return result

        # 罪行分类函数--对str进行分类，返回分类后的列表

    def zuixingfenlei(self, str):
        qiekai = []
        pat = re.compile('被告人(.*?)犯')
        xingming = pat.search(str).group(1)
        qiekai.append(xingming)
        pat = re.compile('犯(.*?)罪')
        zuixing = pat.search(str).group(1)
        qiekai.append(zuixing)
        pat = re.compile('判处(.*?)[，。；（]')
        panjue = pat.search(str).group(1)
        qiekai.append(panjue)
        return qiekai

    def txtborn(self, str):
        self.edge_sum = 0
        self.node_sum = 0
        self.edge_list = []
        self.node_list = []
        self.edge1 = []
        self.edge2 = []
        # self.textEdit.append.write("Source,Target,Label\n")

        # 读文件第三行，获得案件编号
        f = open(str)
        anjianming = f.readlines()[2]
        anjianming = re.sub('\n', '', anjianming)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(anjianming)  # 增加案件名到点标签列表
        f.close()

        # 读文件第四行，获得公诉机关
        f = open(str)
        jiguanming = f.readlines()[3]
        jiguanming = self.gongsujiguan(jiguanming)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(jiguanming)  # 增加机关名到点标签列表
        f.close()
        self.textEdit.append(anjianming + "," + jiguanming + ",公诉机关\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("公诉机关")
        self.edge1.append(1)
        self.edge2.append(2)
        # 读文件第一行，获得审理机关
        f = open(str)
        shenli = f.readlines()[0]
        shenli = re.sub('\n', '', shenli)
        self.node_sum = self.node_sum + 1  # 点的个数加一
        self.node_list.append(shenli)  # 增加机关名到点标签列表
        f.close()
        self.textEdit.append(anjianming + "," + shenli + ",被审理\n")
        self.edge_sum = self.edge_sum + 1
        self.edge_list.append("被审理")
        self.edge1.append(1)
        self.edge2.append(3)
        # 读文件，进行字符串提取信息
        f = open(str)
        txt = f.read()

        xinxihuizong = self.beigaoxinxi(txt)  # 信息汇总是收集所有被告人信息的列表
        beigao_count = 4
        beigao_sum = 0
        for i in xinxihuizong:
            self.xinxifenlei(i, anjianming, beigao_count)
            beigao_count = beigao_count + 6
            beigao_sum = beigao_sum + 1
        beigao_count = 4
        zuixinghuizong = self.zuixingxinxi(txt)  # 罪行汇总是收集所有罪行信息的列表
        xingfa_count = 0
        for i in zuixinghuizong:
            fenleihou = self.zuixingfenlei(i)
            self.textEdit.append(fenleihou[0] + "," + fenleihou[1] + ",罪行\n")
            self.node_sum = self.node_sum + 1
            self.node_list.append(fenleihou[1])
            self.edge_sum = self.edge_sum + 1
            self.edge_list.append("罪行")
            self.edge1.append(beigao_count)
            self.edge2.append(4 + beigao_sum * 6 + xingfa_count * 2)

            self.textEdit.append(fenleihou[0] + "," + fenleihou[2] + ",刑罚\n")
            self.node_sum = self.node_sum + 1
            self.node_list.append(fenleihou[2])
            self.edge_sum = self.edge_sum + 1
            self.edge_list.append("刑罚")
            self.edge1.append(beigao_count)
            self.edge2.append(5 + beigao_sum * 6 + xingfa_count * 2)
            beigao_count = beigao_count + 6
            xingfa_count = xingfa_count + 1
        self.huitu()

    def huitu(self):
        i = 1
        G = nx.DiGraph()  # 创建一个空的有向图
        # 点的创建
        while self.node_sum != 0:
            G.add_node(i)
            i = i + 1
            self.node_sum = self.node_sum - 1
        # 边的创建
        j = 0
        while self.edge_sum != 0:
            G.add_edge(self.edge1[j], self.edge2[j], weight=self.edge_list[j])
            self.edge_sum = self.edge_sum - 1
            j = j + 1
        # 生成节点标签
        labels = {}
        j = 1
        for i in self.node_list:
            labels[j] = i
            j = j + 1

        # 获取graph中的边权重
        edge_labels = nx.get_edge_attributes(G, 'weight')
        # 生成节点位置
        pos = nx.shell_layout(G)
        # 把节点画出来
        nx.draw_networkx_nodes(G, pos, node_size=100, node_color='r', alpha=0.3)

        # 把边画出来
        nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5, edge_color='r', )  # 边是红色的

        # 把节点的标签画出来
        nx.draw_networkx_labels(G, pos, labels, font_size=7, font_color='b')  # 节点标签是蓝色的

        # 把边权重画出来
        nx.draw_networkx_edge_labels(G, pos, edge_labels, font_size=7, font_color='g', )
        plt.savefig("123.png", bbox_inches='tight')
        plt.close()
if __name__ == '__main__':
    app=QApplication(sys.argv)
    main=QMainWindow()

    child=QDialog()#实例化子窗口
    child_ui=Ui_Dialog()#第一个子窗口的地址为ui1
    child_ui.setupUi(child)#显示子窗口
    child1 = QDialog()  # 实例化子窗口
    child1_ui = Ui_Dialog1()  # 第一个子窗口的地址为ui1
    child1_ui.setupUi(child1)  # 显示子窗口
    child2 = QDialog()  # 实例化子窗口
    child2_ui = Ui_Dialog2()  # 第一个子窗口的地址为ui1
    child2_ui.setupUi(child2)  # 显示子窗口
    main_ui=Ui_MainWindow()
    main_ui.setupUi(main)

    btn=main_ui.pushButton#设置点击事件
    btn.clicked.connect(child.show)#设置点击响应
    btn1 = child_ui.pushButton  # 设置点击事件
    btn1.clicked.connect(child1.show)  # 设置点击响应
    btn2 = child_ui.pushButton_2  # 设置点击事件
    btn2.clicked.connect(child2.show)  # 设置点击响应

    main.show()
    sys.exit(app.exec_())