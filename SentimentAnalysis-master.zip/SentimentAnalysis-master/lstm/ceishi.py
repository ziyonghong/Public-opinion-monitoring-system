#! /bin/env python
# -*- coding: utf-8 -*-
"""
预测
"""
import jieba.analyse
import csv
import pandas as pd
import numpy as np
import string
from gensim.models.word2vec import Word2Vec
from gensim.corpora.dictionary import Dictionary
from keras.preprocessing import sequence

from keras import backend as K
K.clear_session()

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *


from PyQt5 import QtCore, QtGui, QtWidgets
import yaml
from keras.models import model_from_yaml

np.random.seed(1337)  # For Reproducibility
import sys
sys.setrecursionlimit(1000000)

# define parameters
maxlen = 100
def create_dictionaries(model=None,
                        combined=None):
    ''' Function does are number of Jobs:
        1- Creates a word to index mapping
        2- Creates a word to vector mapping
        3- Transforms the Training and Testing Dictionaries

    '''
    if (combined is not None) and (model is not None):
        w2indx = {}
        gensim_dict = Dictionary()
        gensim_dict.doc2bow(model.wv.vocab.keys(),
                            allow_update=True)
        #  freqxiao10->0 所以k+1
        f = open("word2index.txt", 'r', encoding='utf8')
        lines = f.readlines()
        for line in lines:
            if line.strip() == '':
                continue
            s = line.split()

        f.close()
        w2indx = {v: k+1 for k, v in gensim_dict.items()}#所有频数超过10的词语的索引,(k->v)=>(v->k)
        w2vec = {word: model[word] for word in w2indx.keys()}#所有频数超过10的词语的词向量, (word->model(word))
    def parse_dataset(combined): # 闭包-->临时使用
            ''' Words become integers
            '''
            data=[]
            for sentence in combined:
                new_txt = []
                for word in sentence:
                    try:
                        new_txt.append(w2indx[word])
                    except:
                        new_txt.append(0) # freqxiao10->0
                data.append(new_txt)
            return data # word=>index
    combined=parse_dataset(combined)
    combined= sequence.pad_sequences(combined, maxlen=maxlen)#每个句子所含词语对应的索引，所以句子中含有频数小于10的词语，索引为0
    return w2indx, w2vec,combined


def input_transform(string):
    words=jieba.lcut(string)
    words=np.array(words).reshape(1,-1)
    model=Word2Vec.load('../model/Word2vec_model.pkl')
    _,_,combined=create_dictionaries(model,words)
    return combined

def tokenizer(text):
    ''' Simple Parser converting each document to lower-case, then
        removing the breaks for new lines and finally splitting on the
        whitespace
    '''
    text = [jieba.lcut(document.replace('\n', '')) for document in text]
    return text



def lstm_predict(string):
    print('loading model......')

    with open('../model/lstm.yml', 'r') as f:
        yaml_string = yaml.load(f)
    model = model_from_yaml(yaml_string)

    print('loading weights......')
    model.load_weights('../model/lstm.h5')
    model.compile(loss='categorical_crossentropy',
                  optimizer='adam',metrics=['accuracy'])
    data=input_transform(string)
    data.reshape(1,-1)
    #print (data)
    result=model.predict_classes(data)
    print(result) # [[1]]

    if result[0]==1:
        return "positive"
    elif result[0]==0:
        return "neural"
    else:
        return "negative"


#if __name__=='__main__':
    #string='酒店的环境非常好，价格也便宜，值得推荐'
    #string='手机质量太差了，赚黑心钱，以后再也不会买了'
    #string = "这是我看过文字写得很糟糕的书，因为买了，还是耐着性子看完了，但是总体来说不好，文字、内容、结构都不好"
    #string = "虽说是职场指导书，但是写的有点干涩，我读一半就看不下去了！"
    #string = "书的质量还好，但是内容实在有些匮乏。本以为会侧重心理方面的分析，但实际上是破案的内容。"
    #string = "五一天气不错，是出去玩的好机会"

   #path = r'红楼梦.txt'
   #path = r'水浒传.txt'
   #with open(path) as file:
        #lines = file.readlines()#读取每一行

        #d = ''#空字符（中间不加空格）
   #for line in lines:

        #d += line.strip()#strip()是去掉每行末尾的换行符\n 1
        #c = d.split()#将a分割成每个字符串 2
        #b = ''.join(c)#将c的每个字符不以任何符号直接连接 3
        #string=b

#lstm_predict(string)
#with open("红楼梦.txt", "r") as f:
      #data = f.read()
      #print(data)
class Ui_Dialog(object):
  result1=''
  #def showre(self):
      #return self.result1
  def setupUi(self, Dialog):
     Dialog.setObjectName("Dialog")
     Dialog.resize(800, 600)
     self.label = QtWidgets.QLabel(Dialog)
     self.label.setGeometry(QtCore.QRect(40, 60, 181, 41))
     self.label.setObjectName("label")
     self.lineEdit = QtWidgets.QLineEdit(Dialog)
     self.lineEdit.setGeometry(QtCore.QRect(70, 100, 331, 41))
     self.lineEdit.setObjectName("lineEdit")
     self.lineEdit2 = QtWidgets.QLineEdit(Dialog)
     self.lineEdit2.setGeometry(QtCore.QRect(70, 300, 331, 41))
     self.lineEdit2.setObjectName("lineEdit2")

     self.pushButton_3 = QtWidgets.QPushButton(Dialog)
     self.pushButton_3.setGeometry(QtCore.QRect(420, 110, 71, 31))
     self.pushButton_3.setObjectName("pushButton_3")
     self.pushButton_2 = QtWidgets.QPushButton(Dialog)
     self.pushButton_2.setGeometry(QtCore.QRect(420, 50, 71, 31))
     self.pushButton_2.setObjectName("pushButton_2")

     self.widget = QtWidgets.QWidget(Dialog)
     self.widget.setGeometry(QtCore.QRect(130, 180, 131, 131))
     self.widget.setObjectName("widget")
     self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
     self.verticalLayout.setContentsMargins(0, 0, 0, 0)
     self.verticalLayout.setObjectName("verticalLayout")
     self.pushButton = QtWidgets.QPushButton(self.widget)
     self.pushButton.setObjectName("pushButton")
     self.verticalLayout.addWidget(self.pushButton)

     Dialog.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
     #设置窗体总显示在最上面
     self.retranslateUi(Dialog)
     self.pushButton.clicked.connect(Dialog.close)
     self.pushButton_2.clicked.connect(self.forlogin)

     self.pushButton_3.clicked.connect(self.lineEdit.clear)


     QtCore.QMetaObject.connectSlotsByName(Dialog)
  def forlogin(self):
        lineEdit = self.lineEdit.text()
        result= lstm_predict(lineEdit)
        self.result1=result
        print(self.result1)
        self.lineEdit2.setText(self.result1)

  def retranslateUi(self, Dialog):
     _translate = QtCore.QCoreApplication.translate
     Dialog.setWindowTitle(_translate("Dialog", "语句分析"))
     self.label.setText(_translate("Dialog", "请输入："))
     self.pushButton_3.setText(_translate("Dialog", "重新输入"))
     self.pushButton_2.setText(_translate("Dialog", "测试"))
     self.pushButton.setText(_translate("Dialog", "下一页"))



import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog
if __name__ == '__main__':
    app = QApplication(sys.argv)  # 实例化主窗口
    main = QDialog()
    main_ui = Ui_Dialog()
    main_ui.setupUi(main)
    main.show()
    sys.exit(app.exec_())