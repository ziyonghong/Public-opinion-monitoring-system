#! /bin/env python
# -*- coding: utf-8 -*-
"""
预测
"""
import jieba.analyse
# WARNING! All changes made in this file will be lost!
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import csv
import pandas as pd
import numpy as np
import string
from gensim.models.word2vec import Word2Vec
from gensim.corpora.dictionary import Dictionary
from keras.preprocessing import sequence
import sys
from keras import backend as K
import pandas as pd
import numpy as np
import jieba
import multiprocessing

from gensim.models.word2vec import Word2Vec
from gensim.corpora.dictionary import Dictionary
from keras.preprocessing import sequence

from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM
from keras.layers.core import Dense, Dropout,Activation
from keras.models import model_from_yaml


np.random.seed(1337)  # For Reproducibility
import sys
sys.setrecursionlimit(1000000)#设置最大递归层数
import yaml
import keras
# set parameters:
cpu_count = multiprocessing.cpu_count() # 4返回当前系统有多少个CPU
vocab_dim = 100
n_iterations =1 # ideally more..
n_exposures = 10 # 所有频数超过10的词语
window_size = 7
n_epoch = 4  #训练轮数
input_length = 100
maxlen = 100
batch_size = 32#一次训练所选取的样本数


K.clear_session()

import yaml
from keras.models import model_from_yaml

np.random.seed(1337)  # For Reproducibility
import sys
sys.setrecursionlimit(1000000)

# define parameters
maxlen = 100

def create_dictionaries(model=None,
                        combined=None):
    ''' Function does are number of Jobs:
        1- Creates a word to index mapping
        2- Creates a word to vector mapping
        3- Transforms the Training and Testing Dictionaries

    '''
    if (combined is not None) and (model is not None):
        w2indx = {}
        gensim_dict = Dictionary()
        gensim_dict.doc2bow(model.wv.vocab.keys(),
                            allow_update=True)
        #  freqxiao10->0 所以k+1
        f = open("word2index.txt", 'r', encoding='utf8')
        lines = f.readlines()
        for line in lines:
            if line.strip() == '':
                continue
            s = line.split()

        f.close()
        w2indx = {v: k+1 for k, v in gensim_dict.items()}#所有频数超过10的词语的索引,(k->v)=>(v->k)
        w2vec = {word: model[word] for word in w2indx.keys()}#所有频数超过10的词语的词向量, (word->model(word))
    def parse_dataset(combined): # 闭包-->临时使用
            ''' Words become integers
            '''
            data=[]
            for sentence in combined:
                new_txt = []
                for word in sentence:
                    try:
                        new_txt.append(w2indx[word])
                    except:
                        new_txt.append(0) # freqxiao10->0
                data.append(new_txt)
            return data # word=>index
    combined=parse_dataset(combined)
    combined= sequence.pad_sequences(combined, maxlen=maxlen)#每个句子所含词语对应的索引，所以句子中含有频数小于10的词语，索引为0
    return w2indx, w2vec,combined


def input_transform(string):
    words=jieba.lcut(string)
    words=np.array(words).reshape(1,-1)
    model=Word2Vec.load('../model/Word2vec_model.pkl')
    _,_,combined=create_dictionaries(model,words)
    return combined

def tokenizer(text):
    ''' Simple Parser converting each document to lower-case, then
        removing the breaks for new lines and finally splitting on the
        whitespace
    '''
    text = [jieba.lcut(document.replace('\n', '')) for document in text]
    return text



def lstm_predict(string):
    print('loading model......')

    with open('../model/lstm.yml', 'r') as f:
        yaml_string = yaml.load(f)
    model = model_from_yaml(yaml_string)

    print('loading weights......')
    model.load_weights('../model/lstm.h5')
    model.compile(loss='categorical_crossentropy',
                  optimizer='adam',metrics=['accuracy'])
    data=input_transform(string)
    data.reshape(1,-1)
    #print (data)
    result=model.predict_classes(data)
    print(result) # [[1]]

    if result[0]==1:
        return "positive"
    elif result[0]==0:
        return "neural"
    else:
        return "negative"

class Ui_MainWindow(object):
   def setupUi(self, MainWindow):
     MainWindow.setObjectName("MainWindow")
     MainWindow.resize(500, 500)
     self.centralwidget = QtWidgets.QWidget(MainWindow)
     self.centralwidget.setObjectName("centralwidget")
     self.label = QtWidgets.QLabel(self.centralwidget)
     self.label.setGeometry(QtCore.QRect(40, 60, 181, 41))
     self.label.setObjectName("label")
     self.pushButton = QtWidgets.QPushButton(self.centralwidget)
     self.pushButton.setGeometry(QtCore.QRect(40, 142, 91, 31))
     self.pushButton.setObjectName("pushButton")
     self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
     self.pushButton_2.setGeometry(QtCore.QRect(194, 142, 91, 31))
     self.pushButton_2.setObjectName("pushButton_2")
     self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
     self.pushButton_3.setGeometry(QtCore.QRect(200, 280, 91, 41))
     self.pushButton_3.setObjectName("pushButton_3")
     self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
     self.pushButton_4.setGeometry(QtCore.QRect(354, 142, 91, 31))
     self.pushButton_4.setObjectName("pushButton_4")
     MainWindow.setCentralWidget(self.centralwidget)
     self.menubar = QtWidgets.QMenuBar(MainWindow)
     self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 23))
     self.menubar.setObjectName("menubar")
     MainWindow.setMenuBar(self.menubar)
     self.statusbar = QtWidgets.QStatusBar(MainWindow)
     self.statusbar.setObjectName("statusbar")
     MainWindow.setStatusBar(self.statusbar)

     self.retranslateUi(MainWindow)
     self.pushButton_3.clicked.connect(MainWindow.close)

     QtCore.QMetaObject.connectSlotsByName(MainWindow)
   def retranslateUi(self, MainWindow):
     _translate = QtCore.QCoreApplication.translate
     MainWindow.setWindowTitle(_translate("MainWindow", "情感分析器"))
     self.label.setText(_translate("MainWindow", "请选择要测试的类型："))
     self.pushButton.setText(_translate("MainWindow", "语句测试"))
     self.pushButton_2.setText(_translate("MainWindow", "文本测试"))
     self.pushButton_3.setText(_translate("MainWindow", "完成"))
     self.pushButton_4.setText(_translate("MainWindow", "查看训练过程"))
#文本子界面
class Ui_Dialog(object):
  result1=''

  def setupUi(self, Dialog):
     Dialog.setObjectName("Dialog")
     Dialog.resize(800, 600)
     self.label = QtWidgets.QLabel(Dialog)
     self.label.setGeometry(QtCore.QRect(40, 60, 181, 41))
     self.label.setObjectName("label")
     self.label_1 = QtWidgets.QLabel(Dialog)
     self.label_1.setGeometry(QtCore.QRect(40, 260, 181, 41))
     self.label_1.setObjectName("label_1")
     self.lineEdit = QtWidgets.QLineEdit(Dialog)
     self.lineEdit.setGeometry(QtCore.QRect(70, 100, 331, 41))
     self.lineEdit.setObjectName("lineEdit")
     self.lineEdit2 = QtWidgets.QLineEdit(Dialog)
     self.lineEdit2.setGeometry(QtCore.QRect(70, 300, 331, 41))
     self.lineEdit2.setObjectName("lineEdit2")

     self.pushButton_3 = QtWidgets.QPushButton(Dialog)
     self.pushButton_3.setGeometry(QtCore.QRect(420, 110, 71, 31))
     self.pushButton_3.setObjectName("pushButton_3")
     self.pushButton_2 = QtWidgets.QPushButton(Dialog)
     self.pushButton_2.setGeometry(QtCore.QRect(420, 250, 71, 31))
     self.pushButton_2.setObjectName("pushButton_2")

     self.widget = QtWidgets.QWidget(Dialog)
     self.widget.setGeometry(QtCore.QRect(230, 380, 131, 131))
     self.widget.setObjectName("widget")
     self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
     self.verticalLayout.setContentsMargins(0, 0, 0, 0)
     self.verticalLayout.setObjectName("verticalLayout")
     self.pushButton = QtWidgets.QPushButton(self.widget)
     self.pushButton.setObjectName("pushButton")
     self.verticalLayout.addWidget(self.pushButton)

     Dialog.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
     #设置窗体总显示在最上面
     self.retranslateUi(Dialog)
     self.pushButton.clicked.connect(Dialog.close)
     self.pushButton_2.clicked.connect(self.forlogin)

     self.pushButton_3.clicked.connect(self.lineEdit.clear)
     self.pushButton_3.clicked.connect(self.lineEdit2.clear)


     QtCore.QMetaObject.connectSlotsByName(Dialog)
  def forlogin(self):
        lineEdit = self.lineEdit.text()
        result= lstm_predict(lineEdit)
        self.result1=result
        print(self.result1)
        self.lineEdit2.setText(self.result1)

  def retranslateUi(self, Dialog):
     _translate = QtCore.QCoreApplication.translate
     Dialog.setWindowTitle(_translate("Dialog", "语句分析"))
     self.label.setText(_translate("Dialog", "请输入："))
     self.label_1.setText(_translate("Dialog", "结果为："))
     self.pushButton_3.setText(_translate("Dialog", "重新输入"))
     self.pushButton_2.setText(_translate("Dialog", "测试"))
     self.pushButton.setText(_translate("Dialog", "完成"))
#文本子界面
class Ui_Dialog2(object):
    result1 = ''

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(800, 600)

        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(40, 60, 181, 41))
        self.label.setObjectName("label")
        self.label_1 = QtWidgets.QLabel(Dialog)
        self.label_1.setGeometry(QtCore.QRect(40, 150, 181, 41))
        self.label_1.setObjectName("labe_1")
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(70, 100, 331, 41))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit2 = QtWidgets.QLineEdit(Dialog)
        self.lineEdit2.setGeometry(QtCore.QRect(70, 200, 331, 41))
        self.lineEdit2.setObjectName("lineEdit2")

        self.pushButton_3 = QtWidgets.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(420, 110, 71, 31))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(420, 50, 71, 31))
        self.pushButton_2.setObjectName("pushButton_2")

        self.widget = QtWidgets.QWidget(Dialog)
        self.widget.setGeometry(QtCore.QRect(130, 200, 131, 131))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)

        Dialog.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
        # 设置窗体总显示在最上面
        self.retranslateUi(Dialog)
        self.pushButton.clicked.connect(Dialog.close)
        self.pushButton_2.clicked.connect(self.chuliwenjian)
        self.pushButton_3.clicked.connect(self.lineEdit.clear)

        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def chuliwenjian(self):
        lineEdit = self.lineEdit.text()
        path = lineEdit

        with open(path) as file:
            lines = file.readlines()  # 读取每一行
            d = ''  # 空字符（中间不加空格）

        for line in lines:
            d += line.strip()  # strip()是去掉每行末尾的换行符\n 1
            c = d.split()  # 将a分割成每个字符串 2
            b = ''.join(c)  # 将c的每个字符不以任何符号直接连接
            string = b
        result = lstm_predict(string)

        self.result1 = result
        self.lineEdit2.setText(self.result1)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "文本分析"))
        self.pushButton_2.setText(_translate("Dialog", "测试"))
        self.label.setText(_translate("Dialog", "请输入文本名"))
        self.label_1.setText(_translate("Dialog", "测试结果"))
        self.pushButton_3.setText(_translate("Dialog", "重新输入"))
        self.pushButton.setText(_translate("Dialog", "下一页"))
class Ui_Dialog3(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(522, 371)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(170, 200, 81, 31))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_1 = QtWidgets.QPushButton(Dialog)
        self.pushButton_1.setGeometry(QtCore.QRect(170, 100, 81, 31))
        self.pushButton_1.setObjectName("pushButton_1")


        self.retranslateUi(Dialog)
        self.pushButton.clicked.connect(Dialog.close)
        self.pushButton_1.clicked.connect(Dialog.close)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "测试结果"))
        self.pushButton.setText(_translate("Dialog", "退出"))
        self.pushButton_1.setText(_translate("Dialog", "继续测试"))

class Ui_Dialog5(object):
     def setupUi(self, Dialog):
         Dialog.setObjectName("Dialog")
         Dialog.resize(400, 300)
         self.pushButton = QtWidgets.QPushButton(Dialog)
         self.pushButton.setGeometry(QtCore.QRect(120, 110, 141, 71))
         self.pushButton.setObjectName("pushButton")

         self.retranslateUi(Dialog)
         self.pushButton.clicked.connect(Dialog.close)
         QtCore.QMetaObject.connectSlotsByName(Dialog)

     def retranslateUi(self, Dialog):
         _translate = QtCore.QCoreApplication.translate
         Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
         self.pushButton.setText(_translate("Dialog", "谢谢使用"))
class Ui_Dialog6(object):

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(459, 348)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(30, 120, 121, 31))
        self.pushButton.setObjectName("pushButton")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(30, 30, 61, 21))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(30, 60, 101, 20))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(170, 60, 101, 16))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(300, 60, 81, 21))
        self.label_4.setObjectName("label_4")

        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(30, 80, 411, 16))
        self.label_5.setObjectName("label_5")
        self.textEdit = QtWidgets.QTextEdit(Dialog)
        self.textEdit.setGeometry(QtCore.QRect(40, 170, 391, 151))
        self.textEdit.setObjectName("textEdit")
        self.textEdit.setText("")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(250, 120, 81, 31))
        self.pushButton_2.setObjectName("pushButton_2")

        self.retranslateUi(Dialog)
        self.pushButton_2.clicked.connect(Dialog.close)
        self.pushButton.clicked.connect(self.xiangying)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def loadfile(self):
            neg = pd.read_csv('../data/neg.csv', header=None, index_col=None)
            pos = pd.read_csv('../data/pos.csv', header=None, index_col=None, error_bad_lines=False)
            neu = pd.read_csv('../data/neutral.csv', header=None, index_col=None)

            combined = np.concatenate((pos[0], neu[0], neg[0]))  # 数组拼接合并语料
            y = np.concatenate((np.ones(len(pos), dtype=int), np.zeros(len(neu), dtype=int),
                                -1 * np.ones(len(neg), dtype=int)))  # ones函数可以创建任意数组，其元素值均为1
            # 初值pos=1，neu=0，neg=-1

            return combined, y

        # 对句子经行分词，并去掉换行符
    def tokenizer(self,text):
            ''' Simple Parser converting each document to lower-case, then
                removing the breaks for new lines and finally splitting on the
                whitespace
            '''
            text = [jieba.lcut(document.replace('\n', '')) for document in text]
            return text

    def create_dictionaries(self,model=None,  # 创建字典
                                combined=None):
            ''' Function does are number of Jobs:
                1- Creates a word to index mapping
                2- Creates a word to vector mapping
                3- Transforms the Training and Testing Dictionaries

            '''
            if (combined is not None) and (model is not None):
                gensim_dict = Dictionary()
                gensim_dict.doc2bow(model.wv.vocab.keys(),  # 获取词表
                                    allow_update=True)
                #  freqxiao10->0 所以k+1
                w2indx = {v: k + 1 for k, v in gensim_dict.items()}  # 所有频数超过10的词语的索引,从1开始编号

                f = open("word2index.txt", 'w', encoding='utf8')
                for key in w2indx:
                    f.write(str(key))
                    f.write(' ')
                    f.write(str(w2indx[key]))
                    f.write('\n')
                f.close()

                w2vec = {word: model[word] for word in w2indx.keys()}  # 所有频数超过10的词语的词向量, (word->model(word))

                def parse_dataset(combined):  # 闭包-->临时使用
                    ''' Words become integers
                    '''
                    data = []
                    for sentence in combined:
                        new_txt = []
                        for word in sentence:
                            try:
                                new_txt.append(w2indx[word])
                            except:
                                new_txt.append(0)  # freqxiao10->0
                        data.append(new_txt)
                    return data  # word=>index

                combined = parse_dataset(combined)
                combined = sequence.pad_sequences(combined, maxlen=maxlen)  # 每个句子所含词语对应的索引，所以句子中含有频数小于10的词语，索引为0
                return w2indx, w2vec, combined
            else:
                print("No data provided...")

        # 创建词语字典，并返回每个词语的索引，词向量，以及每个句子所对应的词语索引
    def word2vec_train(self,combined):
            model = Word2Vec(size=vocab_dim,  # 特征向量的维度
                             min_count=n_exposures,  # 可以对字典做截断. 词频少于min_count次数的单词会被丢弃掉
                             window=window_size,  # 表示当前词与预测词在一个句子中的最大距离是多少
                             workers=cpu_count,  # 参数控制训练的并行数
                             iter=n_iterations)  # 迭代次数
            model.build_vocab(combined)  # input: list
            model.train(combined, total_examples=model.corpus_count, epochs=model.iter)
            model.save('../model/Word2vec_model.pkl')
            index_dict, word_vectors, combined = self.create_dictionaries(model=model, combined=combined)
            return index_dict, word_vectors, combined

    def get_data(self,index_dict, word_vectors, combined, y):

            n_symbols = len(index_dict) + 1  # 所有单词的索引数，频数小于10的词语索引为0，所以加1
            embedding_weights = np.zeros((n_symbols, vocab_dim))  # 初始化 索引为0的词语，词向量全为0
            for word, index in index_dict.items():  # 从索引为1的词语开始，对每个词语对应其词向量
                embedding_weights[index, :] = word_vectors[word]
            x_train, x_test, y_train, y_test = train_test_split(combined, y,
                                                                test_size=0.2)  # combined为样本 y为训练结果 20%为测试集
            y_train = keras.utils.to_categorical(y_train, num_classes=3)  # 标签类别总数设为3，将类向量转换为二进制类矩阵
            y_test = keras.utils.to_categorical(y_test, num_classes=3)
            # print x_train.shape,y_train.shape
            return n_symbols, embedding_weights, x_train, y_train, x_test, y_test

        ##定义网络结构
    def train_lstm(self,n_symbols, embedding_weights, x_train, y_train, x_test, y_test):

            self.textEdit.append('Defining a Simple Keras Model...')
            model = Sequential()  # or Graph or whatever堆叠网络层
            model.add(Embedding(output_dim=vocab_dim,
                                input_dim=n_symbols,
                                mask_zero=True,
                                weights=[embedding_weights],
                                input_length=input_length))  # Adding Input Length
            model.add(LSTM(output_dim=50, activation='tanh'))  # 激活函数
            model.add(Dropout(0.5))  # 防止过拟合0.5的时候dropout随机生成的网络结构最多。
            model.add(Dense(3, activation='softmax'))  # Dense=>全连接层,输出维度=3
            model.add(Activation('softmax'))

            self.textEdit.append('Compiling the Model...')
            model.compile(loss='categorical_crossentropy',  # compile() 函数将一个字符串编译为字节代码
                          optimizer='adam', metrics=['accuracy'])  # 损失函数，优化器

            self.textEdit.append("Train...")
            m_fit=model.fit(x_train, y_train, batch_size=batch_size, epochs=n_epoch, verbose=1)



            self.textEdit.append("Evaluate...")
            score = model.evaluate(x_test, y_test,
                                   batch_size=batch_size)

            yaml_string = model.to_yaml()
            with open('../model/lstm.yml', 'w') as outfile:
                outfile.write(yaml.dump(yaml_string, default_flow_style=True))
            model.save_weights('../model/lstm.h5')  # 权重保存
            #self.textEdit.append('Test score:', score)

    def xiangying(self):

        self.textEdit.append("Loading Data...")
        '''
        combined, y = self.loadfile()
        #self.textEdit.append(len(combined), len(y))

        self.textEdit.append('Tokenising...')
        combined = self.tokenizer(combined)
        self.textEdit.append('Training a Word2vec model...')

        index_dict, word_vectors, combined = self.word2vec_train(combined)
        self.textEdit.append('Setting up Arrays for Keras Embedding Layer...')
        n_symbols, embedding_weights, x_train, y_train, x_test, y_test = self.get_data(index_dict, word_vectors, combined, y)
        self.textEdit.append("x_train.shape and y_train.shape:")
        #self.textEdit.append(x_train.shape, y_train.shape)
        self.train_lstm(n_symbols, embedding_weights, x_train, y_train, x_test, y_test)

'''
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "训练过程"))
        self.pushButton.setText(_translate("Dialog", "查看训练过程"))
        self.label.setText(_translate("Dialog", "参数查看"))
        self.label_2.setText(_translate("Dialog", "输入维度： 100"))
        self.label_3.setText(_translate("Dialog", "最小词频： 10"))
        self.label_4.setText(_translate("Dialog", "窗口值： 7 "))
        self.label_5.setText(_translate("Dialog", "训练轮数： 4 "))

        self.pushButton_2.setText(_translate("Dialog", "返回"))
if __name__ == '__main__':
     app = QApplication(sys.argv)  # 实例化主窗口
     main = QMainWindow()
     main_ui = Ui_MainWindow()
     main_ui.setupUi(main)  # 实例化子窗口
     child = QDialog()  # 第一批子界面
     child1 = QDialog()
     child2 = QDialog()
     child3 = QDialog()
     child4 = QDialog()

     child_ui = Ui_Dialog()
     child_ui.setupUi(child)  # 按钮绑定事件
     btn = main_ui.pushButton
     btn.clicked.connect(child.show)
     btn5 = main_ui.pushButton_3
     btn5.clicked.connect(child3.show)

     child_ui1 = Ui_Dialog2()
     child_ui1.setupUi(child1)
     btn1 = main_ui.pushButton_2
     btn1.clicked.connect(child1.show)

     child_ui2 = Ui_Dialog3()
     child_ui2.setupUi(child2)  # 按钮绑定事件
     btn2 = child_ui.pushButton
     btn2.clicked.connect(child2.show)


     child_ui3 = Ui_Dialog5()
     child_ui3.setupUi(child3)
     btn3 = child_ui2.pushButton
     btn4 = child_ui2.pushButton_1
     btn3.clicked.connect(child3.show)
     btn4.clicked.connect(main.show)

     child_ui4 = Ui_Dialog3()
     child_ui4.setupUi(child2)
     btn4 = child_ui1.pushButton
     btn4.clicked.connect(child2.show)

     child_ui5 = Ui_Dialog6()
     child_ui5.setupUi(child4)
     btn5 = main_ui.pushButton_4
     btn5.clicked.connect(child4.show)
     main.show()
     sys.exit(app.exec_())
