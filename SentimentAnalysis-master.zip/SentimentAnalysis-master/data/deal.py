#! /bin/env python
# -*- coding: utf-8 -*-

import csv

with open("pos.csv", "r",encoding = 'utf-8') as p:
    with open("n_pos.csv", "w") as n:
        read = csv.reader(p)
        for line in p.readlines():
            if line == "\"\n":
                continue
            n.write(line)

line = "\""
print (len(line))