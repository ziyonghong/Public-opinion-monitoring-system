from tkinter import *
def login():
    def print_entry():
    #记录参数
        a = var.get()

    # 标题
    root = Tk()
    root.title("情感分析")
    Frame(root).grid(padx=10, pady=10, ipadx=5)
    # 第一行账号输入框
    username = Label(root, text='请输入一句话：')
    username.grid(row=0, sticky=W)
    var = StringVar()
    # 设置输入框对应的文本变量为var
    Entry(root, textvariable=var).grid(row=0, column=1)
    # 设置输入框对应的文本变量为var
    ps = Entry(root, textvariable=var)
    ps.grid(row=1, column=1)  # 设置输入框对应的文本变量为var
    ps['show'] = '*'  # 隐藏显示
    # 第三行按钮事件
    Button(root, text="预测", command=print_entry).grid(row=2, column=0)
    Button(root, text="取消", command=root.quit).grid(row=2, column=1)
    root.mainloop()
login()