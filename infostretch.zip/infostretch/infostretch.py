# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'infostretch.ui'
#
# Created by: 彭于波
#
# WARNING! All changes made in this file will be lost!

import PyQt5.sip
import collections
from PyQt5.QtWidgets import QApplication, QWidget,QMessageBox, QMainWindow,QScrollArea,QVBoxLayout,QLabel,QFileDialog
import requests
import bs4
import json
import re
import random
from matplotlib import pyplot as plt
import matplotlib as mpl
from progressbar import *
from time import sleep
from PyQt5.QtCore import QThread ,  pyqtSignal,  QDateTime , QObject
from PyQt5 import QtCore, QtGui, QtWidgets

mpl.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
}

iplist = ['112.228.161.57:8118', '125.126.164.21:34592', '122.72.18.35:80', '163.125.151.124:9999',
              '114.250.25.19:80']
def get_random_ip(iplist):
    proxy_list = []
    for ip in iplist:
        proxy_list.append('https://' + ip)
    proxy_ip = random.choice(proxy_list)
    proxies = {'https': proxy_ip}
    return proxies


#搜索系统
class infosys(object):

    def getinfo(self,keys,datasource,s_time='',e_time=''):
        self.s_time, self.e_time = s_time, e_time
        print('开始爬取数据，请耐心等待，，，')
        if 'weiboinfo' in datasource:
            weiboinfo=self.weiboinfo(keys=keys)
        else:
            weiboinfo=[]

        if 'baiduinfo' in datasource:
            baiduinfo=self.baiduinfo(keys=keys)
        else:
            baiduinfo=[]

        if 'xinhuainfo' in datasource:
            xinhuainfo=self.xinhuainfo(keys=keys)
        else:
            xinhuainfo=[]

        if 'xinlanginfo' in datasource:
            xinlanginfo=self.xinlanginfo(keys=keys)
        else:
            xinlanginfo=[]

        if 'sougouinfo' in datasource:
            sougouinfo=self.sougouinfo(keys=keys)
        else:
            sougouinfo=[]

        if 'zhongxininfo' in datasource:
            zhongxininfo=self.zhongxininfo(keys=keys)
        else:
            zhongxininfo=[]
        print('爬取完成！')

        return weiboinfo, baiduinfo, xinhuainfo, xinlanginfo, sougouinfo, zhongxininfo

    def weiboinfo(self,keys):
        infolist = []
        url = 'https://s.weibo.com/article?q=%s&Refer=SListRelpage_box&page=' % keys
        for page in range(1, 50):
            print('weibo crawl:', (page / 49) * 100, '%')
            burl = url + str(page)
            response = requests.get(burl, headers=headers)
            html = response.text
            soup = bs4.BeautifulSoup(html)
            h3_list = soup.select("h3")
            for h in h3_list:
                s = h.find_next('span')
                try:
                    while (s.text.find('@') < 0 and s.text.find('网') < 0):
                        s = s.find_next('span')
                except Exception as e:
                    continue

                p_time=s.find_next('span').text
                if p_time.find('年') < 0:
                    p_time=datetime.datetime.now().strftime('%Y')+'-'+p_time
                p_time=p_time.replace('月','-')
                p_time=p_time.replace('日','-')

                if self.s_time == '' or self.e_time == '':
                    infolist.append(h.text.replace(' ', '') + '\n发帖人：' + s.text + ' 发帖时间：' + p_time)
                elif p_time >= self.s_time and p_time <= self.e_time:
                    infolist.append(h.text.replace(' ', '') + '\n发帖人：' + s.text + ' 发帖时间：' + p_time)
                else:
                    continue

                # print(h.text.replace(' ', '')+'  发帖人：'+s.text+'  发帖时间：'+s.find_next('span').text)
            if len(infolist) >= 300:
                break
        print('weibo crawl complete')
        infolist.append('搜索到相关信息' + str(len(infolist)) + '条.')
        return infolist

    def baiduinfo(self,keys):
        infolist = []
        url = 'https://www.baidu.com/s?tn=news&rtt=1&bsst=1&cl=2&wd=%s&x_bfe_rqs=03E80&x_bfe_tjscore=0.004653&tngroupname=organic_news&pn=' % keys
        for page in range(50):
            print('baidu crawl:', (page / 49) * 100, '%')
            burl = url + str(page) + '0'
            response = requests.get(burl, headers=headers)
            html = response.text
            soup = bs4.BeautifulSoup(html)
            h3_list = soup.select("h3")
            for h in h3_list:
                p = h.find_next('p')
                au = "".join(p.text.split())
                au = au.replace('\n', '')
                au = '\n发帖人：' + au
                for s in au:
                    if s.isdigit():
                        au = au.replace(au[:au.index(s)], au[:au.index(s)] + '   发帖时间：')
                        break
                ct = h.text.replace('\n', '')
                ct = ct.replace(' ', '')
                p_time = au[au.find('发帖时间：') + 5:]
                p_time = p_time.replace('年','-')
                p_time = p_time.replace('月', '-')
                p_time = p_time.replace('日', '-')
                #print(p_time)
                if self.s_time == '' or self.e_time == '':
                    infolist.append(ct + '  ' + au)
                elif p_time >= self.s_time and p_time <= self.e_time:
                    infolist.append(ct + '  ' + au)
                else:
                    continue
                # print(ct +'  '+au)
            if len(infolist) >= 300:
                break
        print('baidu crawl complete')
        infolist.append('搜索到相关信息' + str(len(infolist)) + '条.')
        return infolist

    def xinhuainfo(self,keys):
        infolist = []
        url='http://so.news.cn/getNews?keyword=%s&curPage=&sortField=0&searchFields=1&lang=cn'%keys
        for page in range(1,50):
            print('xinhua crawl:', (page / 49) * 100, '%')
            burl=url.replace('Page=','Page=%d'%page)
            response=requests.get(burl,headers=headers)
            html=response.text
            data=json.loads(html)
            if data['content']['results']==None:
                break
            for result in data['content']['results']:
                if result['des']!=None:
                    p_time=result["pubtime"].replace('/','-')

                    if self.s_time==''or self.e_time=='':
                        infolist.append(result['des'].replace('&nbsp','')+'\n发帖人：'+result["sitename"]+'  发帖时间：'+result["pubtime"])
                    elif p_time>=self.s_time and p_time<=self.e_time:
                        infolist.append(result['des'].replace('&nbsp','')+'\n发帖人：'+result["sitename"]+'  发帖时间：'+result["pubtime"])
                    else:
                        continue
            if len(infolist) > 300:
                break
        print('xinhua crawl complete')
        infolist.append('搜索到相关信息' + str(len(infolist)) + '条.')
        return infolist

    def xinlanginfo(self,keys):
        keys = keys.replace(' ', '+')
        infolist = []
        url = 'http://api.search.sina.com.cn/?c=news&t=&q=%s&pf=2132015312&ps=2130770162&page=&stime=2018-1-31&' \
              'etime=2019-2-1&sort=rel&highlight=1&num=10&ie=utf-8&callback=jQuery17209543781712534618_1545874355621&_=1545874463649' % keys
        for page in range(1, 50):
            print('xinlang crawl:', (page / 49) * 100, '%')
            burl = url.replace('page=', 'page=%d' % page)
            response = requests.get(burl, headers=headers)
            html = response.text
            html = html.replace(html[:41], '')
            html = html.replace(html[-2:], '')
            try:
                data = json.loads(html)
            except Exception:
                continue
            if data['result']['list'] == []:
                break
            for result in data['result']['list']:
                if result['title'] != None:
                    result['title'] = result['title'].replace('<span style="color:#C03">', '')
                    p_time = result["datetime"].replace('/', '-')

                    if self.s_time == '' or self.e_time == '':
                        infolist.append(
                            result['title'].replace('</span>', '') + '\n发帖人：' + result['media'] + '  发帖时间：' + result[
                                'datetime'])
                    elif p_time >= self.s_time and p_time <= self.e_time:
                        infolist.append(
                            result['title'].replace('</span>', '') + '\n发帖人：' + result['media'] + '  发帖时间：' + result[
                                'datetime'])
                    else:
                        continue
            if len(infolist) > 300:
                break
        print('xinlang crawl complete')
        infolist.append('搜索到相关信息' + str(len(infolist)) + '条.')
        return infolist

    def sougouinfo(self,keys):
        keys = keys.replace(' ', '+')
        infolist = []
        url = 'http://news.sogou.com/news?query=%s&page=' % keys
        for page in range(1, 50):
            print('sougou crawl:',(page/49)*100,'%')
            burl = url.replace('page=', 'page=%d' % page)
            response = requests.get(burl, headers=headers)
            html = response.text
            soup = bs4.BeautifulSoup(html)
            h3_list = soup.find_all('h3', class_="vrTitle")
            for h in h3_list:
                p = h.find_next('p', class_="news-from")
                au = '\n发帖人：' + p.text
                for s in au:
                    if s.isdigit():
                        au = au.replace(au[:au.index(s)], au[:au.index(s)] + '   发帖时间：')
                        break
                # print(h.text.replace(' ','')+au)
                p_time=au[au.find('发帖时间：')+5:]
                if p_time.find('分钟前') >= 0 or p_time.find('小时前') >= 0:
                    p_time=datetime.datetime.now().strftime('%Y-%m-%d')

                l = len(p_time)
                f = p_time.find('-')
                r = p_time.find('-', p_time.find('-') + 1)
                if r - f == 2:
                    p_time = p_time[:f + 1] + '0' + p_time[f + 1:]
                if l - r == 2:
                    p_time = p_time[:r + 1 + len(p_time) - l] + '0' + p_time[r + 1 + len(p_time) - l:]
                #print('sogou',p_time, self.s_time, self.e_time)

                if self.s_time=='':
                    infolist.append(h.text.replace(' ', '') + au)
                elif p_time>=self.s_time and p_time<=self.e_time:
                    infolist.append(h.text.replace(' ', '') + au)
                else:
                    continue
            if len(infolist) > 300:
                break
        print('sougou crawl complete')
        infolist.append('搜索到相关信息' + str(len(infolist)) + '条.')
        return infolist

    def zhongxininfo(self,keys):
        infolist = []
        keys = keys.replace(' ', '')
        data = {
            'q': keys,
            'ps': '10',
            'start': '0',
            'type': '',
            'sort': 'pubtime',
            'time_scope': '0',
            'channel': 'all',
            'adv': '1',
            'day1': '',
            'day2': '',
            'field': '',
            'creator': '',
        }
        url = 'http://sou.chinanews.com/search.do?q=%s' % keys
        for page in range(0, 50):
            print('zhongxin crawl:', (page / 49) * 100, '%')
            data['start'] = str(page) + '0'
            response = requests.post(url, data=data, headers=headers)
            html = response.text
            soup = bs4.BeautifulSoup(html)
            l_list = soup.select("li")
            if l_list == []:
                break
            sr = ''
            for l in l_list:
                if str(l.get("class")) == "['news_title']":
                    sr = sr + l.text
                if str(l.get("class")) == "['news_other']":
                    au = '\n发帖人：' + l.text
                    au = "".join(au.split())
                    au = au.replace('html', '  发帖时间：')
                    sr = sr + au
                    p_time = au[au.find('发帖时间：') + 5:]

                    if self.s_time == '':
                        infolist.append(sr)
                        sr = ''
                    elif p_time >= self.s_time and p_time <= self.e_time:
                        infolist.append(sr)
                        sr = ''
                    else:
                        sr = ''
                        continue
                    #print(sr)

            if len(infolist) > 300:
                break
        print('zhongxin crawl complete')
        infolist.append('搜索到相关信息' + str(len(infolist)) + '条.')
        return infolist

#变化趋势绘图系统
class changestatistics(object):
    def __init__(self,keys):
        self.keys=keys

    def baiduinfo(self):
        infolist = []
        url = 'https://www.baidu.com/s?tn=news&rtt=1&bsst=1&cl=2&wd=%s&x_bfe_rqs=03E80&x_bfe_tjscore=0.004653&tngroupname=organic_news&pn=' % self.keys
        for page in range(30):
            print('baidu crawl:', (page / 30) * 100, '%')
            burl = url + str(page) + '0'
            response = requests.get(burl, headers=headers)
            html = response.text
            soup = bs4.BeautifulSoup(html)
            h3_list = soup.select("h3")
            for h in h3_list:
                p = h.find_next('p')
                au = "".join(p.text.split())
                au = au.replace('\n', '')
                au = '\n发帖人：' + au
                for s in au:
                    if s.isdigit():
                        au = au.replace(au[:au.index(s)], au[:au.index(s)] + '   发帖时间：')
                        break
                ct = h.text.replace('\n', '')
                ct = ct.replace(' ', '')
                p_time = au[au.find('发帖时间：') + 5:]
                #print(p_time)
                if (ct + '  ' + au).find(self.keys)>=0:
                    infolist.append(ct + '  ' + au)

                # print(ct +'  '+au)
        print('爬取完成')
        if infolist==[]:
            print('抱歉，没有找到相关信息。。')
            return
        self.getx_y(infolist)

    def getx_y(self,list):
        newlist = []
        for str in list:
            str = str.replace(str[:str.index('发帖时间：')+5], '')
            #print(str)
            if str.find('201') < 0:
                date = datetime.datetime.now().strftime('%Y-%m-%d')
                newlist.append(date)

            if str.find('201') >= 0:
                str = str.replace('年', '-')
                str = str.replace('月', '-')
                newlist.append(str[:10])
                #print(str)


        x_list = []
        y_list = []
        for n in newlist:
            if n not in x_list:
                x_list.append(n)
        for x in x_list:
            y_list.append(newlist.count(x))
        self.drawtable(x_list,y_list)

    def drawtable(self,x_list,y_list):
        plt.figure(1)
        #del x_list[3]
        #del y_list[3]
        index=[]
        for i in range(len(x_list)):
            index.append(i)
        index = [float(c) for c in index]
        plt.plot(x_list,y_list)
        plt.xticks(index, x_list,rotation=45)
        plt.title(self.keys+'近期变化趋势')
        plt.xlabel('日期')
        plt.ylabel(self.keys+'的话题量')

        if len(x_list)>50:
            s1='高'
        elif len(x_list)>25:
            s1='中'
        else:
            s1='低'

        index=y_list.index(max(y_list))
        s2=x_list[index-1]+'到'+x_list[index+1]
        plt.text(len(x_list) * 0.2, max(y_list)*0.85, '舆情关注度：%s'%s1,
                 fontdict={'size': 15, 'color': 'b'})
        plt.text(len(x_list) * 0.2, max(y_list) * 0.7, '关注度最高的时间段：%s'%s2,
                 fontdict={'size': 15, 'color': 'b'})
        #plt.legend(['train', 'validation'], loc='upper left')
        plt.show()

#热门话题统计
class topicstatistics(object):
    def __init__(self,keys):
        self.keys=keys

    def topicinfo(self):
        url='https://s.weibo.com/topic?q=%s&pagetype=topic&topic=1&Refer=article_topic'%self.keys
        response=requests.get(url,headers=headers)
        html=response.text
        soup=bs4.BeautifulSoup(html)
        div_list=soup.select("div")
        topic={}
        for div in div_list:
            if str(div.get("class"))=="['info']":
                try:
                    s=div.select("p")[1].text
                    s=s.replace(s[s.index("论"):],'')
                    if s.find('万')>=0:
                        hot=re.sub('\D','',s)
                        topic[div.select("a")[0].text]=int(hot+'0000')
                    else:
                        hot = re.sub('\D', '', s)
                        topic[div.select("a")[0].text] = int(hot)
                except Exception as e:
                    print(e)
                    continue
        return self.drawtable(topic)

    def drawtable(self,topic):
        plt.figure(2)
        name_list = list(topic.keys())
        num_list = list(topic.values())
        plt.title("对于"+self.keys+"的话题关注点")
        plt.barh(range(len(num_list)), num_list,tick_label = name_list)
        plt.show()

#主界面
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(314, 302)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.line_5 = QtWidgets.QFrame(self.centralwidget)
        self.line_5.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_5.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_5.setObjectName("line_5")
        self.verticalLayout.addWidget(self.line_5)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout.addWidget(self.pushButton_3)
        self.line_2 = QtWidgets.QFrame(self.centralwidget)
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.verticalLayout.addWidget(self.line_2)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.line_3 = QtWidgets.QFrame(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(False)
        font.setWeight(50)
        self.line_3.setFont(font)
        self.line_3.setLineWidth(1)
        self.line_3.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        self.verticalLayout.addWidget(self.line_3)
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setObjectName("pushButton_4")
        self.verticalLayout.addWidget(self.pushButton_4)
        self.line_4 = QtWidgets.QFrame(self.centralwidget)
        self.line_4.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_4.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_4.setObjectName("line_4")
        self.verticalLayout.addWidget(self.line_4)
        self.label = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 314, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)


        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "基于爬虫的多角度网络舆情信息自动化采集软件V1.0"))
        self.pushButton_2.setText(_translate("MainWindow", "舆情信息采集"))
        self.pushButton_3.setText(_translate("MainWindow", "舆情信息统计"))
        self.pushButton.setText(_translate("MainWindow", "实时热点监测"))
        self.pushButton_4.setText(_translate("MainWindow", "舆情趋势监测"))
        self.label.setText(_translate("MainWindow", "作者：彭于波  2019.2.28"))

#舆情信息采集窗口
class Ui_datastrtech(QWidget):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1079, 254)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.frame.setObjectName("frame")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.frame)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.line_9 = QtWidgets.QFrame(self.frame)
        self.line_9.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_9.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_9.setObjectName("line_9")
        self.gridLayout_2.addWidget(self.line_9, 5, 0, 1, 1)
        self.checkBox_6 = QtWidgets.QCheckBox(self.frame)
        self.checkBox_6.setObjectName("checkBox_6")
        self.gridLayout_2.addWidget(self.checkBox_6, 6, 10, 1, 1)
        self.lineEdit_4 = QtWidgets.QLineEdit(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.lineEdit_4.setFont(font)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.gridLayout_2.addWidget(self.lineEdit_4, 8, 8, 2, 1)
        self.dateEdit_2 = QtWidgets.QDateEdit(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.dateEdit_2.setFont(font)
        self.dateEdit_2.setObjectName("dateEdit_2")
        self.gridLayout_2.addWidget(self.dateEdit_2, 8, 4, 2, 1)
        self.line = QtWidgets.QFrame(self.frame)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.gridLayout_2.addWidget(self.line, 7, 0, 2, 11)
        self.checkBox_7 = QtWidgets.QCheckBox(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.checkBox_7.setFont(font)
        self.checkBox_7.setObjectName("checkBox_7")
        self.gridLayout_2.addWidget(self.checkBox_7, 9, 0, 1, 1)
        self.checkBox_8 = QtWidgets.QCheckBox(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(False)
        font.setWeight(50)
        self.checkBox_8.setFont(font)
        self.checkBox_8.setObjectName("checkBox_8")
        self.gridLayout_2.addWidget(self.checkBox_8, 9, 6, 1, 1)
        self.dateEdit = QtWidgets.QDateEdit(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.dateEdit.setFont(font)
        self.dateEdit.setObjectName("dateEdit")
        self.gridLayout_2.addWidget(self.dateEdit, 8, 2, 2, 1)
        self.pushButton_2 = QtWidgets.QPushButton(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout_2.addWidget(self.pushButton_2, 8, 10, 2, 1)
        self.line_7 = QtWidgets.QFrame(self.frame)
        self.line_7.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_7.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_7.setObjectName("line_7")
        self.gridLayout_2.addWidget(self.line_7, 4, 9, 3, 2)
        self.checkBox = QtWidgets.QCheckBox(self.frame)
        self.checkBox.setObjectName("checkBox")
        self.gridLayout_2.addWidget(self.checkBox, 6, 0, 1, 1)
        self.checkBox_2 = QtWidgets.QCheckBox(self.frame)
        self.checkBox_2.setObjectName("checkBox_2")
        self.gridLayout_2.addWidget(self.checkBox_2, 6, 2, 1, 1)
        self.checkBox_3 = QtWidgets.QCheckBox(self.frame)
        self.checkBox_3.setObjectName("checkBox_3")
        self.gridLayout_2.addWidget(self.checkBox_3, 6, 4, 1, 1)
        self.checkBox_4 = QtWidgets.QCheckBox(self.frame)
        self.checkBox_4.setObjectName("checkBox_4")
        self.gridLayout_2.addWidget(self.checkBox_4, 6, 6, 1, 1)
        self.checkBox_5 = QtWidgets.QCheckBox(self.frame)
        self.checkBox_5.setObjectName("checkBox_5")
        self.gridLayout_2.addWidget(self.checkBox_5, 6, 8, 1, 1)
        self.line_6 = QtWidgets.QFrame(self.frame)
        self.line_6.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_6.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_6.setObjectName("line_6")
        self.gridLayout_2.addWidget(self.line_6, 4, 7, 3, 2)
        self.label_13 = QtWidgets.QLabel(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_13.setFont(font)
        self.label_13.setAutoFillBackground(False)
        self.label_13.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.label_13.setAlignment(QtCore.Qt.AlignCenter)
        self.label_13.setObjectName("label_13")
        self.gridLayout_2.addWidget(self.label_13, 2, 0, 1, 1)
        self.label_21 = QtWidgets.QLabel(self.frame)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(15)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.label_21.setFont(font)
        self.label_21.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.label_21.setObjectName("label_21")
        self.gridLayout_2.addWidget(self.label_21, 0, 0, 1, 1)
        self.line_8 = QtWidgets.QFrame(self.frame)
        self.line_8.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_8.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_8.setObjectName("line_8")
        self.gridLayout_2.addWidget(self.line_8, 1, 0, 1, 11)
        self.label_3 = QtWidgets.QLabel(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label_3.setFont(font)
        self.label_3.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 2, 8, 1, 1)
        self.lineEdit = QtWidgets.QLineEdit(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.lineEdit.setFont(font)
        self.lineEdit.setObjectName("lineEdit")
        self.gridLayout_2.addWidget(self.lineEdit, 2, 2, 1, 1)
        self.lineEdit_3 = QtWidgets.QLineEdit(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.lineEdit_3.setFont(font)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.gridLayout_2.addWidget(self.lineEdit_3, 2, 6, 1, 1)
        self.pushButton = QtWidgets.QPushButton(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout_2.addWidget(self.pushButton, 2, 10, 1, 1)
        self.line_2 = QtWidgets.QFrame(self.frame)
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.gridLayout_2.addWidget(self.line_2, 3, 0, 1, 11)
        self.line_5 = QtWidgets.QFrame(self.frame)
        self.line_5.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_5.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_5.setObjectName("line_5")
        self.gridLayout_2.addWidget(self.line_5, 4, 1, 3, 2)
        self.line_4 = QtWidgets.QFrame(self.frame)
        self.line_4.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_4.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_4.setObjectName("line_4")
        self.gridLayout_2.addWidget(self.line_4, 4, 3, 3, 2)
        self.line_3 = QtWidgets.QFrame(self.frame)
        self.line_3.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        self.gridLayout_2.addWidget(self.line_3, 4, 5, 3, 2)
        self.label = QtWidgets.QLabel(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.label.setFont(font)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.gridLayout_2.addWidget(self.label, 4, 0, 1, 1)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.frame)
        font = QtGui.QFont()
        font.setPointSize(11)
        self.lineEdit_2.setFont(font)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.gridLayout_2.addWidget(self.lineEdit_2, 2, 4, 1, 1)
        self.gridLayout.addWidget(self.frame, 0, 0, 1, 1)
        self.line_10 = QtWidgets.QFrame(self.centralwidget)
        self.line_10.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_10.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_10.setObjectName("line_10")
        self.gridLayout.addWidget(self.line_10, 1, 0, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1079, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.keys=''


        self.retranslateUi(MainWindow)
        self.pushButton.clicked.connect(self.getsearchkeys)
        self.pushButton_2.clicked.connect(self.keepdata)

        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        QMessageBox.information(self, "提示", "欢迎使用！")


    #确定搜索时间段
    def getTime(self):
        s_time=self.dateEdit.text().replace('/','-')
        e_time=self.dateEdit_2.text().replace('/','-')

        l = len(s_time)
        f = s_time.find('-')
        r = s_time.find('-', s_time.find('-') + 1)
        if r - f == 2:
            s_time = s_time[:f + 1] + '0' + s_time[f + 1:]
        if l - r == 2:
            s_time = s_time[:r + 1 + len(s_time) - l] + '0' + s_time[r + 1 + len(s_time) - l:]

        l = len(e_time)
        f = e_time.find('-')
        r = e_time.find('-', e_time.find('-') + 1)
        if r - f == 2:
            e_time = e_time[:f + 1] + '0' + e_time[f + 1:]
        if l - r == 2:
            e_time = e_time[:r + 1 + len(e_time) - l] + '0' + e_time[r + 1 + len(e_time) - l:]
        return s_time, e_time

    # 确定数据源
    def getsource(self):
        datasource = []
        if self.checkBox.isChecked():
            datasource.append('xinlanginfo')
        if self.checkBox_2.isChecked():
            datasource.append('sougouinfo')
        if self.checkBox_3.isChecked():
            datasource.append('zhongxininfo')
        if self.checkBox_4.isChecked():
            datasource.append('weiboinfo')
        if self.checkBox_5.isChecked():
            datasource.append('baiduinfo')
        if self.checkBox_6.isChecked():
            datasource.append('xinhuainfo')
        return datasource

    # 搜索系统
    def getsearchkeys(self):
        lt=[]
        if self.lineEdit.text()!='':
            lt.append(self.lineEdit.text())
        if self.lineEdit_2.text()!='':
            lt.append(self.lineEdit_2.text())
        if self.lineEdit_3.text()!='':
            lt.append(self.lineEdit_3.text())
        if len(lt)==0:
            self.keys=''
        elif len(lt)==1:
            self.keys=lt[0]
        elif len(lt)==2:
            self.keys=lt[0]+' '+lt[1]
        else:
            self.keys=lt[0]+' '+lt[1]+' '+lt[2]

        if self.keys == '':
            QMessageBox.information(self,'提示','搜索内容为空！')
            return
        datasource=self.getsource()

        if datasource==[]:
            QMessageBox.information(self, "提示", "请至少选择一个数据源！")
            return

        if self.checkBox_7.isChecked():
            self.s_time,self.e_time=self.getTime()
            if self.s_time>self.e_time:
                QMessageBox.information(self, "提示", "时间段输入不合法，开始时间应早于结束时间！")
                return
            self.weiboinfo, self.baiduinfo, self.xinhuainfo, self.xinlanginfo, \
            self.sougouinfo, self.zhongxininfo = infosys().getinfo(self.keys, datasource, self.s_time, self.e_time)

        else:
            self.weiboinfo, self.baiduinfo, self.xinhuainfo, self.xinlanginfo, \
            self.sougouinfo, self.zhongxininfo = infosys().getinfo(self.keys, datasource)

        (self.weiboitxt,self.baidutxt,self.xinhuatxt,self.xinlangtxt,self.sougoutxt,self.zhongxintxt) = ([],[],[],[],[],[])
        index=len(lt)
        for i in self.weiboinfo:
            if i.find(lt[index-1]) >= 0:
                self.weiboitxt.append(i)
        self.weiboitxt.append('相关信息共收集到：' + str(len(self.weiboitxt)) + '条')
        self.weiboitxt.insert(0, '微博信息采集结果：\n')
        if self.checkBox_4.isChecked():
            ScrollMessageBox(self.weiboitxt, None)

        for i in self.baiduinfo:
            if i.find(lt[index - 1]) >= 0:
                self.baidutxt.append(i)
        self.baidutxt.append('相关信息共收集到：' + str(len(self.baidutxt)) + '条')
        self.baidutxt.insert(0, '百度信息采集结果：\n')
        if self.checkBox_5.isChecked():
            ScrollMessageBox(self.baidutxt, None)

        for i in self.xinhuainfo:
            if i.find(lt[index - 1]) >= 0:
                self.xinhuatxt.append(i)
        self.xinhuatxt.append('相关信息共收集到：' + str(len(self.xinhuatxt)) + '条')
        self.xinhuatxt.insert(0, '新华网信息采集结果：\n')
        if self.checkBox_6.isChecked():
            ScrollMessageBox(self.xinhuatxt, None)

        for i in self.xinlanginfo:
            if i.find(lt[index - 1]) >= 0:
                self.xinlangtxt.append(i)
        self.xinlangtxt.append('相关信息共收集到：' + str(len(self.xinlangtxt)) + '条')
        self.xinlangtxt.insert(0, '新浪信息采集结果：\n')
        if self.checkBox.isChecked():
            ScrollMessageBox(self.xinlangtxt, None)

        for i in self.sougouinfo:
            if i.find(lt[index - 1]) >= 0:
                self.sougoutxt.append(i)
        self.sougoutxt.append('相关信息共收集到：' + str(len(self.sougoutxt)) + '条')
        self.sougoutxt.insert(0, '搜狗信息采集结果：\n')
        if self.checkBox_2.isChecked():
            ScrollMessageBox(self.sougoutxt, None)

        for i in self.zhongxininfo:
            if i.find(lt[index - 1]) >= 0:
                self.zhongxintxt.append(i)
        self.zhongxintxt.append('相关信息共收集到：'+str(len(self.zhongxintxt))+'条')
        self.zhongxintxt.insert(0, '中新网信息采集结果：\n')
        if self.checkBox_3.isChecked():
            ScrollMessageBox(self.zhongxintxt, None)

    #保存数据
    def keepdata(self):
        if self.checkBox_8.isChecked():
            path=self.lineEdit_4.text()
        else :
            path=os.getcwd()
        date=self.dateEdit.text()+'到'+self.dateEdit_2.text()
        if self.keys=='':
            QMessageBox.information(self, "提示", "保存失败！")
            return
        filename = self.keys.replace(' ','_') + ' ' + date.replace('/','-')
        try:
            file = open(path+'/'+filename + '.json', 'w+')
        except Exception as e:
            QMessageBox.information(self, "警告", "路径不合法！")
            return
        file.write('{}\n')
        file.close()
        with open(path+'/'+filename + '.json', 'r')as ifile:
            info = json.load(ifile)
        with open(path+'/'+filename + '.json', 'w')as ofile:
            info['xinlang']=self.xinlanginfo
            info['baidu']=self.baiduinfo
            info['weibo']=self.weiboinfo
            info['zhongxin']=self.zhongxininfo
            info['sougou']=self.sougouinfo
            info['xinhua']=self.xinhuainfo

            try:
                json.dump(info,ofile, indent=4)
            except Exception as e:
                print(e)
                QMessageBox.information(self, "提示", "保存失败！")
                return
        QMessageBox.information(self, "提示", "保存成功！\n保存路径："+path+"\\"+filename)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "基于爬虫的多角度网络舆情信息自动化采集软件V1.0"))
        self.label_21.setText(_translate("MainWindow", "舆情信息采集"))
        self.label.setText(_translate("MainWindow", "请选择采集的数据源"))
        self.checkBox.setText(_translate("MainWindow", "新浪信息采集"))
        self.checkBox_2.setText(_translate("MainWindow", "搜狗信息采集"))
        self.checkBox_3.setText(_translate("MainWindow", "中新网信息采集"))
        self.checkBox_4.setText(_translate("MainWindow", "微博信息采集"))
        self.checkBox_5.setText(_translate("MainWindow", "百度信息采集"))
        self.checkBox_6.setText(_translate("MainWindow", "新华网信息采集"))
        self.pushButton_2.setText(_translate("MainWindow", "保存信息"))
        self.label_13.setText(_translate("MainWindow", "请输入你要搜索的关键词"))
        self.pushButton.setText(_translate("MainWindow", "搜索"))
        self.label_3.setText(_translate("MainWindow", "最多输入三个关键词哦"))
        self.checkBox_7.setText(_translate("MainWindow", "自定义爬取时段(可选)"))
        self.checkBox_8.setText(_translate("MainWindow", "请输入保存路径(可选)"))

class ScrollMessageBox(QMessageBox):
    def __init__(self, l,*args, **kwargs):
        QMessageBox.__init__(self, *args, **kwargs)
        _translate = QtCore.QCoreApplication.translate
        QMessageBox.setWindowTitle(self,'信息采集结果')
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        self.content = QWidget()
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.content.setFont(font)
        scroll.setWidget(self.content)
        lay = QVBoxLayout(self.content)
        for item in l:
            lay.addWidget(QLabel(item, self))
        self.layout().addWidget(scroll, 0, 0, 1, self.layout().columnCount())
        self.setStyleSheet("QScrollArea{min-width:500 px; min-height: 600px}")
        self.exec_()

#舆情信息统计窗口
class Ui_datacount(QWidget):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(910, 700)
        self.gridLayout = QtWidgets.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.gridLayout.addLayout(self.horizontalLayout, 8, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(Form)
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 4, 0, 1, 1)
        self.pushButton_4 = QtWidgets.QPushButton(Form)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setObjectName("pushButton_4")
        self.gridLayout.addWidget(self.pushButton_4, 2, 1, 1, 1)
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout.addWidget(self.pushButton, 2, 2, 1, 1)
        self.label = QtWidgets.QLabel(Form)
        self.label.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 2, 0, 1, 1)
        self.tableWidget = QtWidgets.QTableWidget(Form)
        self.tableWidget.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.tableWidget.setObjectName("tableWidget")
        self.cols_nb = 6
        self.rows_nb = 100
        #设置行列
        self.tableWidget.setColumnCount(self.cols_nb)
        self.tableWidget.setRowCount(self.rows_nb)

        for i in range(self.rows_nb):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setVerticalHeaderItem(i, item)
        for i in range(self.cols_nb):
            item = QtWidgets.QTableWidgetItem()
            self.tableWidget.setHorizontalHeaderItem(i, item)

        self.gridLayout.addWidget(self.tableWidget, 4, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(Form)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 0, 0, 1, 1)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.line = QtWidgets.QFrame(Form)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.gridLayout.addWidget(self.line, 5, 0, 1, 3)
        self.line_2 = QtWidgets.QFrame(Form)
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.gridLayout.addWidget(self.line_2, 3, 0, 1, 3)
        self.line_3 = QtWidgets.QFrame(Form)
        self.line_3.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        self.gridLayout.addWidget(self.line_3, 1, 0, 1, 3)



        #to do:
        self.pushButton.clicked.connect(self.statistics_table)
        self.pushButton_4.clicked.connect(self.opendir)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
        QMessageBox.information(self, "提示", "舆情信息统计模块所用统计数据文件必须是使用软件自带的信息采集模块所采集的数据文件！！")


    def opendir(self):
        self.jaonfile,filetype=QFileDialog.getOpenFileNames(self, "选取待统计数据", "C:/", "Json Files (*.json);;All Files (*.)")
        #print(self.jaonfile)
    #表格写入数据
    def statistics_table(self):
        jsonfiles=self.jaonfile
        if jsonfiles==[]:
            QMessageBox.information(self, "提示", "选取文件为空！")
            return

        rows_nb=len(jsonfiles)

        for i in range(rows_nb):
            for j in range(self.cols_nb):
                item = QtWidgets.QTableWidgetItem()
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                self.tableWidget.setItem(i, j, item)

        #设置表格内容
        __sortingEnabled = self.tableWidget.isSortingEnabled()
        _translate = QtCore.QCoreApplication.translate
        self.tableWidget.setSortingEnabled(False)
        data_list=[]
        for js in jsonfiles:
            if js.find('json')>=0:
                data_list.append(js)
        for i in range(len(data_list)):
            row_list=self.statistics_items(jsonfiles[i],jsonfiles[i].split('/')[-1].replace('.json',''))
            for j in range(self.cols_nb):
                item = self.tableWidget.item(i, j)
                item.setText(_translate("Form", row_list[j]))
        self.tableWidget.setSortingEnabled(__sortingEnabled)

    #统计数据
    def statistics_items(self,filepath,filename):
        print(filepath)
        row_list=[]
        #print(filename)
        keyname=filename[:filename.find(' ')]
        row_list.append(keyname)
        sertime=filename[filename.find(' ')+1:]
        if sertime.find('2000')>=0:
            date = datetime.datetime.now().strftime('%Y-%m-%d')
            row_list.append('-'+date)
        else:
            row_list.append(sertime)

        #统计发帖人
        with open(filepath , 'r') as infile:
            data = json.load(infile)
        count = len(data['xinhua']) + len(data['baidu']) + len(data['weibo']) + len(data['xinlang']) + len(data['zhongxin']) + len(data['sougou'])
        row_list.append(str(count))
        ftmen = []
        for keys in data.items():
            for content in keys[1]:
                if content.find('发帖人') < 0:
                    continue
                ftmen.append(content[content.find('发帖人') + 4:content.find('发帖时间') - 2])
        result = collections.Counter(ftmen)
        # 排序
        d = sorted(result.items(), key=lambda x: x[1], reverse=True)
        #print(d)
        row_list.append(d[0][0] + '(' + str(d[0][1]) + ')')
        row_list.append(d[1][0] + '(' + str(d[1][1]) + ')')
        row_list.append(d[2][0] + '(' + str(d[2][1]) + ')')
        return row_list


    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "基于爬虫的多角度网络舆情信息自动化采集软件V1.0"))
        self.label_2.setText(_translate("Form", "统计结果"))
        self.pushButton.setText(_translate("Form", "统计"))
        self.pushButton_4.setText(_translate("Form", "打开目录"))
        self.label.setText(_translate("Form", "请输入数据路径"))

        for i in range(self.rows_nb):
            item = self.tableWidget.verticalHeaderItem(i)
            item.setText(_translate("Form", str(i)))

        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("Form", "关键词"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("Form", "统计时间段"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("Form", "统计数量"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("Form", "主要发帖人1"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("Form", "主要发帖人2"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("Form", "主要发帖人3"))
        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.label_3.setText(_translate("Form", "舆情信息统计"))

#实时热点监测窗口
class BackendThread(QObject):
    # 通过类成员对象定义信号
    update_date = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
    # 处理业务逻辑
    def run(self):
        while True:
            data = QDateTime.currentDateTime()
            self.update_date.emit(1)
            sleep(30)

class hotsearch(object):
    def getpostlist(self):
        url = 'http://tieba.baidu.com/hottopic/browse/topicList?res_type=1&red_tag=t2615953323'
        response = requests.get(url, headers=headers)
        html = response.text
        soup = bs4.BeautifulSoup(html)
        topic_text = []
        topic_num = []
        a_list = soup.select("a")
        span_list = soup.select("span")
        for a in a_list:
            if str(a.get("class")) == "['topic-text']":
                topic_text.append(str(a.text))
        for span in span_list:
            if str(span.get("class")) == "['topic-num']":
                topic_num.append(str(span.text))
        return topic_text, topic_num

    def gethotlist(self):
        url = 'https://s.weibo.com/top/summary?Refer=top_hot&topnav=1&wvr=6'
        response = requests.get(url, headers=headers)
        html = response.text
        soup = bs4.BeautifulSoup(html)
        td_list = soup.select("td")
        keys = []
        hotdu = []
        mark = []
        for td in td_list:
            if str(td.get("class")) == "['td-02']":
                try:
                    keys.append(td.select("a")[0].text)
                    hotdu.append(td.select("span")[0].text)
                except Exception:
                    hotdu.append('置顶')
            if str(td.get("class")) == "['td-03']":
                mark.append(td.text)
        return keys, hotdu, mark

    def getnowhot(self):
        url = 'http://top.baidu.com/buzz?b=1&c=513&fr=topbuzz_b1_c513'
        response = requests.get(url, headers=headers)
        response.encoding = 'gb2312'
        html = response.text
        soup = bs4.BeautifulSoup(html)
        topic_text = []
        topic_num = []
        a_list = soup.select("a")
        td_list = soup.select("td")

        for a in a_list:
            if str(a.get("class")) == "['list-title']":
                topic_text.append(str(a.text))
        for td in td_list:
            if str(td.get("class")) == "['last']":
                topic_num.append(str(td.text))
        return topic_text, topic_num

class Ui_realhot(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(948, 632)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(20)
        sizePolicy.setVerticalStretch(20)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        MainWindow.setMinimumSize(QtCore.QSize(632, 632))
        MainWindow.setAnimated(True)
        MainWindow.setTabShape(QtWidgets.QTabWidget.Rounded)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.textBrowser_3 = QtWidgets.QTextBrowser(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.textBrowser_3.setFont(font)
        self.textBrowser_3.setObjectName("textBrowser_3")
        self.gridLayout.addWidget(self.textBrowser_3, 6, 2, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 4, 1, 1, 1)
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setBold(False)
        font.setWeight(50)
        self.textBrowser.setFont(font)
        self.textBrowser.setObjectName("textBrowser")
        self.gridLayout.addWidget(self.textBrowser, 6, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 4, 0, 1, 1)
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        self.textBrowser_2.setFont(font)
        self.textBrowser_2.setObjectName("textBrowser_2")
        self.gridLayout.addWidget(self.textBrowser_2, 6, 1, 1, 1)
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_5.setFont(font)
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setObjectName("label_5")
        self.gridLayout.addWidget(self.label_5, 4, 2, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Bahnschrift SemiBold")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 3, 0, 1, 1)
        self.horizontalLayout.addLayout(self.gridLayout)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 632, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.initUI()

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "基于爬虫的多角度网络舆情信息自动化采集软件V1.0"))
        self.label.setText(_translate("MainWindow", "实时热点监测"))
        self.label_4.setText(_translate("MainWindow", "微博实时热搜排行"))
        self.label_3.setText(_translate("MainWindow", "贴吧实时热搜排行"))
        self.label_5.setText(_translate("MainWindow", "百度实时热搜排行"))
        self.label_2.setText(_translate("MainWindow", "更新时间："))

    # 实时系统
    def initUI(self):
        # 创建线程
        self.backend = BackendThread()
        # 连接信号
        self.backend.update_date.connect(self.showinfo)
        self.thread = QThread()
        self.backend.moveToThread(self.thread)

        # 开始线程
        self.thread.started.connect(self.backend.run)
        self.thread.start()

    def showinfo(self):
        topic_text, topic_num = hotsearch().getpostlist()
        keys, hotdu, mark = hotsearch().gethotlist()
        # 设置时间
        date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.label_2.clear()
        self.label_2.setText("更新时间： " + date)
        # 设置热搜界面
        self.textBrowser.clear()
        self.textBrowser_2.clear()
        self.textBrowser_3.clear()
        for i in range(20):
            self.textBrowser.append(str(i + 1) + " " + topic_text[i] + '\n' + topic_num[i] + '\n')
        for i in range(50):
            self.textBrowser_2.append(str(i + 1) + " " + keys[i] + '\n' + hotdu[i] + '\n')
        topic_text, topic_num = hotsearch().getnowhot()
        for i in range(50):
            self.textBrowser_3.append(str(i + 1) + " " + topic_text[i] + " " + topic_num[i])
        self.textBrowser.show()
        self.textBrowser_2.show()
        self.textBrowser_3.show()

#舆情趋势监测系统
class Ui_datachange(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(344, 382)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        MainWindow.setFont(font)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")
        self.line_4 = QtWidgets.QFrame(self.centralwidget)
        self.line_4.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_4.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_4.setObjectName("line_4")
        self.verticalLayout.addWidget(self.line_4)
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label_3.setFrameShape(QtWidgets.QFrame.WinPanel)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.verticalLayout.addWidget(self.label_3)
        self.line_5 = QtWidgets.QFrame(self.centralwidget)
        self.line_5.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_5.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_5.setObjectName("line_5")
        self.verticalLayout.addWidget(self.line_5)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.horizontalLayout_2.addWidget(self.label)
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(18)
        self.lineEdit.setFont(font)
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout_2.addWidget(self.lineEdit)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.line_3 = QtWidgets.QFrame(self.centralwidget)
        self.line_3.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        self.verticalLayout.addWidget(self.line_3)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.line_2 = QtWidgets.QFrame(self.centralwidget)
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.verticalLayout.addWidget(self.line_2)
        self.line_6 = QtWidgets.QFrame(self.centralwidget)
        self.line_6.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_6.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_6.setObjectName("line_6")
        self.verticalLayout.addWidget(self.line_6)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 344, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.pushButton.clicked.connect(self.gettopictable)
        self.pushButton_2.clicked.connect(self.getchangetable)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    # 获取变化趋势
    def getchangetable(self):
        keys = self.lineEdit.text()
        if keys == '':
            QMessageBox.information(self, "提示", "关键词为空！")
            return
        changestatistics(keys).baiduinfo()

    # 获取有关话题
    def gettopictable(self):
        keys = self.lineEdit.text()
        if keys == '':
            QMessageBox.information(self, "提示", "关键词为空！")
            return
        topicstatistics(keys).topicinfo()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "基于爬虫的多角度网络舆情信息自动化采集软件V1.0"))
        self.label_3.setText(_translate("MainWindow", "舆情趋势监测"))
        self.label.setText(_translate("MainWindow", "请输入关键字"))
        self.pushButton_2.setText(_translate("MainWindow", "了解近期变化趋势"))
        self.pushButton.setText(_translate("MainWindow", "了解有关热门话题"))

class parentWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.main_ui = Ui_MainWindow()
        self.main_ui.setupUi(self)

class childWindow0(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.child=Ui_datastrtech()
        self.child.setupUi(self)

class childWindow1(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.child=Ui_datacount()
        self.child.setupUi(self)

class childWindow2(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.child=Ui_realhot()
        self.child.setupUi(self)

class childWindow3(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.child=Ui_datachange()
        self.child.setupUi(self)

if __name__=='__main__':
    app=QApplication(sys.argv)
    main_win=parentWindow()
    get_info_win=childWindow0()
    static_info_win=childWindow1()
    realhot_win=childWindow2()
    datachange_win=childWindow3()


    #通过Button将两个窗体关联
    btn0=main_win.main_ui.pushButton_2
    btn0.clicked.connect(get_info_win.show)

    btn1 = main_win.main_ui.pushButton_3
    btn1.clicked.connect(static_info_win.show)

    btn2 = main_win.main_ui.pushButton
    btn2.clicked.connect(realhot_win.show)

    btn3 = main_win.main_ui.pushButton_4
    btn3.clicked.connect(datachange_win.show)

    # 显示
    main_win.show()
    sys.exit(app.exec_())
