from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication,QMainWindow
import Frame.secondFrame

class FirstFrame(QMainWindow):
    def __init__(self,*args, **kwargs):
        super().__init__(*args, **kwargs)
        self.windowList=[]
        self.setObjectName("MainWindow")
        self.resize(695, 621)
        self.centralwidget = QtWidgets.QWidget()
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(-30, -50, 1171, 721))
        self.frame.setTabletTracking(False)
        self.frame.setStyleSheet("background-image: url(bg.png)")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.frame.setLineWidth(0)
        self.frame.setObjectName("frame")
        self.start = QtWidgets.QPushButton(self.frame)
        self.start.setGeometry(QtCore.QRect(190, 490, 111, 41))
        font = QtGui.QFont()
        font.setFamily("华文琥珀")
        font.setPointSize(18)
        self.start.setFont(font)
        self.start.setStyleSheet("background-image: url(start.png);")
        self.start.setText("")
        self.start.setObjectName("start")
        self.exit = QtWidgets.QPushButton(self.frame)
        self.exit.setGeometry(QtCore.QRect(440, 490, 111, 41))
        self.exit.setStyleSheet("background-image: url(exit.png);")
        self.exit.setText("")
        self.exit.setObjectName("exit")
        self.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar()
        self.menubar.setGeometry(QtCore.QRect(0, 0, 695, 26))
        self.menubar.setObjectName("menubar")
        self.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar()
        self.statusbar.setObjectName("statusbar")
        self.setStatusBar(self.statusbar)

        self.start.clicked.connect(self.on_start)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def on_start(self):
        the_window = Frame.secondFrame.SecondFrame()
        self.windowList.append(the_window)
        self.close()
        the_window.show()

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("MainWindow", "校园舆情监测系统"))
