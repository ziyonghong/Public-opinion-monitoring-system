import sys
import Frame.first
from PyQt5.QtWidgets import QApplication,QMainWindow

if __name__ == '__main__':
    app=QApplication(sys.argv)
    the_mainwindow = Frame.first.FirstFrame()
    the_mainwindow.show()
    sys.exit(app.exec_())